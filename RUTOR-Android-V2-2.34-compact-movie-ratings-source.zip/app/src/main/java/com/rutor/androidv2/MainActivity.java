package com.rutor.androidv2;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.*;
import android.text.method.LinkMovementMethod;
import android.view.*;
import android.widget.*;
import org.jsoup.*;
import org.jsoup.nodes.*;
import org.jsoup.select.Elements;
import java.util.*;
import java.util.concurrent.*;
import org.json.*;
import java.net.*;
import java.io.*;

public class MainActivity extends Activity {
    private static final String DEFAULT_BASE = "https://rutor.is";
    private String BASE = DEFAULT_BASE;
    private final ExecutorService pool = Executors.newFixedThreadPool(4);
    private final int BG = Color.BLACK, FG = Color.WHITE, ACCENT = Color.rgb(88,200,239);
    private final int YELLOW = Color.rgb(255,220,0), RED = Color.rgb(170,0,0);
    private LinearLayout tableRows;
    private int selectedRow = -1;
    private LinearLayout root, body, bar;
    private String currentUrl = DEFAULT_BASE, listUrl = DEFAULT_BASE, currentTitle = "", screen = "list";
    private boolean favoritesMode = false;
    private String currentCategory = "0", currentQuery = "";
    private String dateFrom = "", dateTo = "";
    private int sortBy = 0;
    private boolean sortDescending = true;
    private final ArrayDeque<String> history = new ArrayDeque<>();
    private android.content.SharedPreferences prefs;

    @Override public void onCreate(Bundle b) { super.onCreate(b); prefs=getSharedPreferences("rutor",MODE_PRIVATE); BASE=prefs.getString("site_domain",DEFAULT_BASE); showList(BASE,false); }
    private int dp(int n){return (int)(getResources().getDisplayMetrics().density*n+.5f);}
    private TextView text(String s,int size,boolean bold){ TextView t=new TextView(this); t.setText(s);t.setTextColor(FG);t.setTextSize(size); if(bold)t.setTypeface(null,Typeface.BOLD);t.setPadding(dp(12),dp(9),dp(12),dp(9)); return t; }
    private GradientDrawable shape(){GradientDrawable d=new GradientDrawable();d.setColor(Color.rgb(15,15,15));d.setCornerRadius(dp(9));return d;}
    private void init(String title){
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(BG);setContentView(root);
        bar=new LinearLayout(this);bar.setOrientation(LinearLayout.HORIZONTAL);bar.setGravity(Gravity.CENTER_VERTICAL);root.addView(bar);
        if(!screen.equals("list")){TextView back=text("‹",30,true);bar.addView(back);back.setOnClickListener(v->goBack());}
        if(!title.isEmpty()){TextView heading=text(title,20,true);heading.setSingleLine(true);heading.setEllipsize(TextUtils.TruncateAt.END);bar.addView(heading,new LinearLayout.LayoutParams(0,dp(58),1));}
        ScrollView sc=new ScrollView(this);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setPadding(screen.equals("list")?0:dp(8),dp(4),screen.equals("list")?0:dp(8),dp(20));sc.addView(body);
    }
    private void notice(String message){body.addView(text(message,15,false));}
    private void load(String url, java.util.function.Consumer<Document> done){
        notice("Загрузка…");pool.execute(()->{
            try {Document doc=Jsoup.connect(url).userAgent("Mozilla/5.0 (Android 14; Mobile) AppleWebKit/537.36 Chrome/120.0 Safari/537.36").timeout(18000).followRedirects(true).get();runOnUiThread(()->{if(!isFinishing()){body.removeAllViews();done.accept(doc);}});}
            catch(Exception e){runOnUiThread(()->{if(!isFinishing()){body.removeAllViews();notice("Не удалось загрузить страницу: "+e.getMessage()+"\nПроверь интернет или доступность выбранного домена.");}});}
        });
    }
    private TextView cell(String value,int size,boolean bold,int color){
        TextView t=text(value,size,bold);
        t.setTextColor(color);
        t.setPadding(dp(4),dp(9),dp(4),dp(9));
        t.setGravity(Gravity.CENTER_VERTICAL);
        t.setMaxLines(2);
        t.setEllipsize(TextUtils.TruncateAt.END);
        return t;
    }
    private void tableHeader(){
        // No yellow table header: keep only Categories and Search above releases.
        tableRows=new LinearLayout(this);
        tableRows.setOrientation(LinearLayout.VERTICAL);
        body.addView(tableRows);
    }
    private void tab(LinearLayout parent,String label,boolean active,Runnable action){
        TextView t=cell(label,14,true,active?Color.BLACK:Color.WHITE);
        t.setGravity(Gravity.CENTER);
        GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
          active?new int[]{Color.YELLOW,YELLOW}:new int[]{Color.RED,Color.rgb(90,0,0)});
        d.setCornerRadii(new float[]{dp(7),dp(7),dp(7),dp(7),0,0,0,0});
        t.setBackground(d);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(45),1);
        lp.setMargins(dp(1),0,dp(1),0);
        parent.addView(t,lp);
        t.setOnClickListener(v->action.run());
    }
    private void showList(String url,boolean favorite){
        screen="list";favoritesMode=favorite;listUrl=url;currentUrl=url;selectedRow=-1;
        init("");
        // Tappable Rutor banner: open the domain switcher.
        ImageView logoBanner=new ImageView(this);
        logoBanner.setImageResource(R.drawable.rutor_red_header);
        logoBanner.setScaleType(ImageView.ScaleType.FIT_XY);
        logoBanner.setContentDescription("Rutor — изменить домен сайта");
        LinearLayout.LayoutParams logoLp=new LinearLayout.LayoutParams(-1,dp(30));
        body.addView(logoBanner,logoLp);
        logoBanner.setOnClickListener(v->showDomainDialog());
        // Two independent actions: categories and full advanced search.
        LinearLayout nav=new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        body.addView(nav,new LinearLayout.LayoutParams(-1,dp(39)));
        TextView categories=cell("Категории ▾",17,true,Color.BLACK);
        categories.setGravity(Gravity.CENTER);
        categories.setBackgroundColor(YELLOW);
        nav.addView(categories,new LinearLayout.LayoutParams(0,-1,1));
        categories.setOnClickListener(v->categoryDialog());
        View separator=new View(this);separator.setBackgroundColor(BG);
        nav.addView(separator,new LinearLayout.LayoutParams(dp(3),-1));
        TextView searchButton=cell("Поиск",17,true,Color.BLACK);
        searchButton.setGravity(Gravity.CENTER);
        searchButton.setBackgroundColor(YELLOW);
        nav.addView(searchButton,new LinearLayout.LayoutParams(0,-1,1));
        searchButton.setOnClickListener(v->showAdvancedSearch());
        if(!currentQuery.isEmpty()||!currentCategory.equals("0")||!dateFrom.isEmpty()||!dateTo.isEmpty()){
            TextView filter=text((!currentQuery.isEmpty()?"Поиск: "+currentQuery:"Категория: "+categoryName(currentCategory))+(dateFrom.isEmpty()&&dateTo.isEmpty()?"":" · "+(dateFrom.isEmpty()?"…":dateFrom)+" — "+(dateTo.isEmpty()?"…":dateTo))+"   ✕",13,false);
            body.addView(filter);
            filter.setOnClickListener(v->{currentCategory="0";currentQuery="";dateFrom="";dateTo="";showList(BASE,false);});
        }
        tableHeader();
        if(favorite){
            Set<String> saved=prefs.getStringSet("favorites",Collections.emptySet());
            if(saved.isEmpty())tableRows.addView(text("Избранное пока пусто",15,false));
            for(String item:saved){int k=item.indexOf('|');
                if(k>0)addItem(item.substring(0,k),item.substring(k+1),"—","—","—");}
            return;
        }
        tableRows.addView(text("Загрузка раздач…",15,false));
        pool.execute(()->{
            try{
                Document doc=Jsoup.connect(url).userAgent("Mozilla/5.0 (Android; Mobile) Chrome/120.0").timeout(18000).get();
                ArrayList<String[]> found=new ArrayList<>();HashSet<String> seen=new HashSet<>();
                for(Element a:doc.select("tr.gai a[href], tr.tum a[href], #index a[href], table a[href]")){
                    String href=a.absUrl("href"),title=a.text().trim();
                    if(href.matches("(?i).*/torrent/\\d+.*")&&title.length()>3&&seen.add(href)){
                        Element tr=a.closest("tr");
                        String date="—",size="—",peers="—";
                        if(tr!=null){
                            Elements td=tr.select("> td");
                            if(td.size()>0)date=td.get(0).text();
                            if(td.size()>2)size=td.get(td.size()-2).text();
                            if(td.size()>3)peers=td.get(td.size()-1).text();
                        }
                        // Hide the three permanent tracker announcements on the home screen.
                        if((title.toLowerCase(Locale.ROOT).contains("новый адрес: rutor")
                            || title.toLowerCase(Locale.ROOT).contains("вечная блокировка в россии")
                            || title.toLowerCase(Locale.ROOT).contains("путеводитель по rutor")))continue;
                        String releaseCategory="";
                        if(tr!=null){
                            Element catLink=tr.selectFirst("a[href*=browse/0/]");
                            if(catLink!=null){
                                java.util.regex.Matcher cm=java.util.regex.Pattern.compile("/browse/0/(\\d+)").matcher(catLink.attr("href"));
                                if(cm.find())releaseCategory=cm.group(1);
                            }
                        }
                        if(dateInRange(date))found.add(new String[]{title,href,date,size,peers,releaseCategory});
                    }
                }
                sortResults(found);
                runOnUiThread(()->{
                    if(!screen.equals("list")||favoritesMode||!listUrl.equals(url))return;
                    tableRows.removeAllViews();
                    if(found.isEmpty())tableRows.addView(text("Раздачи не найдены. Проверь поисковый запрос или выбери другую категорию.",15,false));
                    for(String[] pair:found)addItem(pair[0],pair[1],pair[2],pair[3],pair[4],pair[5]);
                });
            }catch(Exception e){runOnUiThread(()->{
                if(screen.equals("list")&&listUrl.equals(url)){
                    tableRows.removeAllViews();
                    tableRows.addView(text("Ошибка загрузки: "+e.getMessage(),15,false));
                }
            });}
        });
    }
    private void showAdvancedSearch(){
        screen="search";
        init("Расширенный поиск");
        addSection(body,"Расширенный поиск RUTOR");
        EditText query=new EditText(this);
        query.setSingleLine(true);
        query.setTextColor(FG);
        query.setHintTextColor(Color.LTGRAY);
        query.setHint("Название, актёр, год или ключевые слова");
        query.setText(currentQuery);
        query.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH);
        body.addView(query,new LinearLayout.LayoutParams(-1,dp(56)));
        TextView categoryLabel=text("Категория",15,true);
        body.addView(categoryLabel);
        String[] labels={"Все категории","Зарубежные фильмы","Наши фильмы","Сериалы","Мультфильмы","Музыка","Игры","Программы","Книги"};
        String[] ids={"0","1","5","4","7","2","8","9","11"};
        Spinner spinner=new Spinner(this);
        ArrayAdapter<String> adapter=categoryAdapter(labels);
        spinner.setAdapter(adapter);
        body.addView(spinner,new LinearLayout.LayoutParams(-1,dp(52)));
        for(int i=0;i<ids.length;i++)if(ids[i].equals(currentCategory)){spinner.setSelection(i);break;}
        TextView sortLabel=text("Упорядочить по",15,true);
        body.addView(sortLabel);
        String[] sortLabels={"дате добавления","раздающим","качающим","названию","размеру","релевантности"};
        Spinner sortSpinner=new Spinner(this);
        sortSpinner.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,sortLabels));
        sortSpinner.setSelection(sortBy);
        body.addView(sortSpinner,new LinearLayout.LayoutParams(-1,dp(50)));
        RadioGroup direction=new RadioGroup(this);
        direction.setOrientation(RadioGroup.HORIZONTAL);
        RadioButton ascending=new RadioButton(this);
        ascending.setText("по возрастанию");
        ascending.setTextSize(13);
        RadioButton descending=new RadioButton(this);
        descending.setText("по убыванию");
        descending.setTextSize(13);
        ascending.setId(View.generateViewId());
        descending.setId(View.generateViewId());
        direction.addView(ascending,new RadioGroup.LayoutParams(0,dp(44),1));
        direction.addView(descending,new RadioGroup.LayoutParams(0,dp(44),1));
        direction.check(sortDescending?descending.getId():ascending.getId());
        body.addView(direction);
        TextView dateLabel=text("Отображать по дате",15,true);
        dateLabel.setPadding(dp(8),dp(10),dp(8),dp(3));
        body.addView(dateLabel);
        LinearLayout dateRow=new LinearLayout(this);
        dateRow.setOrientation(LinearLayout.HORIZONTAL);
        dateRow.setGravity(Gravity.CENTER_VERTICAL);
        body.addView(dateRow,new LinearLayout.LayoutParams(-1,dp(55)));
        TextView from=makeDateField("С",dateFrom);
        TextView to=makeDateField("До",dateTo);
        dateRow.addView(from,new LinearLayout.LayoutParams(0,dp(50),1));
        dateRow.addView(to,new LinearLayout.LayoutParams(0,dp(50),1));
        from.setOnClickListener(v->pickDate(from,true));
        to.setOnClickListener(v->pickDate(to,false));
        TextView dateHelp=text("Нажми на поле, чтобы выбрать дату. Пустое поле — без ограничения.",11,false);
        dateHelp.setTextColor(Color.LTGRAY);
        dateHelp.setPadding(dp(8),0,dp(8),dp(5));
        body.addView(dateHelp);
        TextView submit=text("Найти раздачи",17,true);
        submit.setGravity(Gravity.CENTER);
        submit.setBackgroundColor(RED);
        LinearLayout.LayoutParams buttonParams=new LinearLayout.LayoutParams(-1,dp(52));
        buttonParams.setMargins(0,dp(14),0,0);
        body.addView(submit,buttonParams);
        Runnable search=()->{
            String q=query.getText().toString().trim();
            if(!dateFrom.isEmpty()&&!dateTo.isEmpty()&&parseFilterDate(dateFrom)>parseFilterDate(dateTo)){
                Toast.makeText(this,"Дата «С» должна быть раньше даты «До»",Toast.LENGTH_LONG).show();
                return;
            }
            currentCategory=ids[spinner.getSelectedItemPosition()];
            sortBy=sortSpinner.getSelectedItemPosition();
            sortDescending=direction.getCheckedRadioButtonId()!=ascending.getId();
            if(q.isEmpty()){
                currentQuery="";
                showList(BASE+"/browse/0/"+currentCategory+"/0/0",false);
            }else performSearch(q);
        };
        submit.setOnClickListener(v->search.run());
        query.setOnEditorActionListener((v,action,event)->{search.run();return true;});
    }
    private double peerNumber(String peers,int index){
        java.util.regex.Matcher matcher=java.util.regex.Pattern.compile("\\d+").matcher(peers);
        int count=0;
        while(matcher.find()){
            if(count++==index)try{return Double.parseDouble(matcher.group());}catch(Exception ignored){}
        }
        return 0;
    }
    private double sizeBytes(String value){
        java.util.regex.Matcher matcher=java.util.regex.Pattern.compile("([0-9]+(?:[.,][0-9]+)?)\\s*(TB|GB|MB|KB|ТБ|ГБ|МБ|КБ|B)",java.util.regex.Pattern.CASE_INSENSITIVE).matcher(value);
        if(!matcher.find())return 0;
        double n;
        try{n=Double.parseDouble(matcher.group(1).replace(',','.'));}catch(Exception e){return 0;}
        String unit=matcher.group(2).toUpperCase(Locale.ROOT);
        if(unit.equals("TB")||unit.equals("ТБ"))return n*1099511627776d;
        if(unit.equals("GB")||unit.equals("ГБ"))return n*1073741824d;
        if(unit.equals("MB")||unit.equals("МБ"))return n*1048576d;
        if(unit.equals("KB")||unit.equals("КБ"))return n*1024d;
        return n;
    }
    private void sortResults(ArrayList<String[]> results){
        if(sortBy==5)return;
        Collections.sort(results,(a,b)->{
            int comparison=0;
            switch(sortBy){
                case 0: comparison=Long.compare(parseReleaseDate(a[2]),parseReleaseDate(b[2]));break;
                case 1: comparison=Double.compare(peerNumber(a[4],0),peerNumber(b[4],0));break;
                case 2: comparison=Double.compare(peerNumber(a[4],1),peerNumber(b[4],1));break;
                case 3: comparison=a[0].compareToIgnoreCase(b[0]);break;
                case 4: comparison=Double.compare(sizeBytes(a[3]),sizeBytes(b[3]));break;
            }
            return sortDescending?-comparison:comparison;
        });
    }
    private TextView makeDateField(String label,String value){
        TextView field=text(label+": "+(value.isEmpty()?"дд.мм.гггг":value),14,false);
        field.setGravity(Gravity.CENTER);
        field.setTextColor(Color.WHITE);
        GradientDrawable border=shape();
        border.setStroke(dp(1),Color.GRAY);
        field.setBackground(border);
        return field;
    }
    private void pickDate(TextView field,boolean isFrom){
        Calendar c=Calendar.getInstance();
        String existing=isFrom?dateFrom:dateTo;
        if(!existing.isEmpty()){
            String[] parts=existing.split("\\.");
            if(parts.length==3)try{
                c.set(Integer.parseInt(parts[2]),Integer.parseInt(parts[1])-1,Integer.parseInt(parts[0]));
            }catch(NumberFormatException ignored){}
        }
        DatePickerDialog dialog=new DatePickerDialog(this,(picker,year,month,day)->{
            String value=String.format(Locale.ROOT,"%02d.%02d.%04d",day,month+1,year);
            if(isFrom)dateFrom=value;else dateTo=value;
            field.setText((isFrom?"С: ":"До: ")+value);
        },c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH));
        dialog.setButton(android.content.DialogInterface.BUTTON_NEUTRAL,"Очистить",(d,w)->{
            if(isFrom)dateFrom="";else dateTo="";
            field.setText(isFrom?"С: дд.мм.гггг":"До: дд.мм.гггг");
        });
        dialog.show();
    }
    private long parseFilterDate(String value){
        if(value==null||value.isEmpty())return -1;
        try{
            java.text.SimpleDateFormat format=new java.text.SimpleDateFormat("dd.MM.yyyy",Locale.ROOT);
            format.setLenient(false);
            return format.parse(value).getTime();
        }catch(Exception ignored){return -1;}
    }
    private long parseReleaseDate(String value){
        // RUTOR displays dates like "01 Ноя 26" and sometimes "01 Ноя".
        java.util.regex.Matcher m=java.util.regex.Pattern.compile("(\\d{1,2})\\s+([\\p{L}]+)(?:\\s+(\\d{2,4}))?",java.util.regex.Pattern.CASE_INSENSITIVE|java.util.regex.Pattern.UNICODE_CASE).matcher(value);
        if(!m.find())return -1;
        String month=m.group(2).toLowerCase(new Locale("ru"));
        String[] months={"янв","фев","мар","апр","мая","май","июн","июл","авг","сен","сент","окт","ноя","дек"};
        int[] monthIndexes={0,1,2,3,4,4,5,6,7,8,8,9,10,11};
        int idx=-1;
        for(int i=0;i<months.length;i++)if(month.startsWith(months[i])){idx=monthIndexes[i];break;}
        if(idx<0)return -1;
        try{
            int year=m.group(3)==null?Calendar.getInstance().get(Calendar.YEAR):Integer.parseInt(m.group(3));
            if(year<100)year+=2000;
            Calendar c=Calendar.getInstance();
            c.clear();
            c.setLenient(false);
            c.set(year,idx,Integer.parseInt(m.group(1)));
            return c.getTimeInMillis();
        }catch(Exception ignored){return -1;}
    }
    private boolean dateInRange(String releaseDate){
        if(dateFrom.isEmpty()&&dateTo.isEmpty())return true;
        long actual=parseReleaseDate(releaseDate);
        if(actual<0)return false;
        long start=parseFilterDate(dateFrom),end=parseFilterDate(dateTo);
        return (start<0||actual>=start)&&(end<0||actual<=end);
    }
    private void searchDialog(){
        EditText field=new EditText(this);
        field.setSingleLine(true);
        new AlertDialog.Builder(this).setTitle("Поиск RUTOR").setView(field)
          .setPositiveButton("Найти",(d,w)->{
              String q=field.getText().toString().trim();
              if(!q.isEmpty())performSearch(q);
          }).setNegativeButton("Отмена",null).show();
    }
    private void addItem(String title,String url,String date,String size,String peers){
        addItem(title,url,date,size,peers,"");
    }
    private int releaseIcon(String title,String category){
        String t=title.toLowerCase(Locale.ROOT);
        if(t.matches("(?s).*(\\bfb2\\b|\\bepub\\b|\\bmobi\\b|аудиокниг|\\bкнига\\b|\\bкниги\\b|собрание сочинений).*"))return R.drawable.flat_books;
        if(t.matches("(?s).*(дискография|\\bflac\\b|\\bmp3\\b|\\baac\\b|\\bape\\b|альбом|саундтрек).*"))return R.drawable.flat_music;
        if(t.matches("(?s).*(\\bapk\\b|\\biso\\b.*игра|repack|\\bsteamrip\\b|\\bgog\\b|\\bpc game\\b).*"))return R.drawable.flat_games;
        if(t.matches("(?s).*(мультфильм|аниме|мультсериал|\\bcartoon\\b).*"))return R.drawable.flat_cartoon;
        if(t.matches("(?s).*(\\bhdtv\\b|\\bwebrip\\b.*сериал|\\bs\\d{1,2}e\\d{1,2}\\b|сезон|\\b\\d{1,2}x\\d{2}\\b).*"))return R.drawable.flat_series;
        if(category.isEmpty())category=currentCategory;
        switch(category){
            case "1":return R.drawable.flat_movie;
            case "5":return R.drawable.flat_movie;
            case "4":return R.drawable.flat_series;
            case "7":return R.drawable.flat_cartoon;
            case "2":return R.drawable.flat_music;
            case "8":return R.drawable.flat_games;
            case "9":return R.drawable.flat_programs;
            case "11":return R.drawable.flat_books;
        }
        if(t.matches("(?s).*(\\b1080p\\b|\\b720p\\b|\\b2160p\\b|\\bbdremux\\b|\\bbdrip\\b|\\bweb-dl\\b).*"))return R.drawable.flat_movie;
        return R.drawable.flat_all;
    }
    private void addItem(String title,String url,String date,String size,String peers,String category){
        LinearLayout row=new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setBackgroundColor(tableRows.getChildCount()%2==0?Color.rgb(12,12,12):Color.rgb(27,31,33));

        // The date belongs to the release title, not a separate table column.
        LinearLayout titleColumn=new LinearLayout(this);
        titleColumn.setOrientation(LinearLayout.VERTICAL);
        titleColumn.setPadding(dp(10),dp(3),dp(1),dp(3));
        TextView dateView=text(date.replaceAll("\\s+", " ").trim(),10,false);
        dateView.setTextColor(Color.rgb(190,190,190));
        dateView.setIncludeFontPadding(false);
        dateView.setSingleLine(true);
        titleColumn.addView(dateView);
        TextView nameView=text(title,12,true);
        nameView.setTextColor(Color.WHITE);
        nameView.setIncludeFontPadding(false);
        nameView.setMaxLines(2);
        nameView.setEllipsize(TextUtils.TruncateAt.END);
        nameView.setPadding(0,dp(1),0,0);
        LinearLayout titleLine=new LinearLayout(this);
        titleLine.setGravity(Gravity.CENTER_VERTICAL);
        ImageView categoryIcon=new ImageView(this);
        categoryIcon.setImageResource(releaseIcon(title,category));
        categoryIcon.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams iconParams=new LinearLayout.LayoutParams(dp(28),dp(28));
        iconParams.setMargins(0,0,dp(7),0);
        titleLine.addView(categoryIcon,iconParams);
        nameView.setPadding(0,dp(1),0,0);
        titleLine.addView(nameView,new LinearLayout.LayoutParams(0,-2,1));
        titleColumn.addView(titleLine);
        row.addView(titleColumn,new LinearLayout.LayoutParams(0,dp(66),77));

        TextView sizeView=cell(size,12,false,Color.WHITE);
        sizeView.setGravity(Gravity.CENTER);
        row.addView(sizeView,new LinearLayout.LayoutParams(0,dp(66),13));

        // RUTOR peers: seeders first (green), leechers second (red).
        java.util.regex.Matcher numbers=java.util.regex.Pattern.compile("\\d[\\d\\s,]*").matcher(peers);
        String seed="0", leech="0";
        java.util.ArrayList<String> counts=new java.util.ArrayList<>();
        while(numbers.find()){
            for(String part:numbers.group().trim().split("[\\s,]+"))
                if(!part.isEmpty())counts.add(part);
        }
        if(counts.size()>0)seed=counts.get(0);
        if(counts.size()>1)leech=counts.get(1);
        LinearLayout peersView=new LinearLayout(this);
        peersView.setGravity(Gravity.CENTER);
        peersView.setOrientation(LinearLayout.HORIZONTAL);
        TextView seedView=cell(seed,12,true,Color.rgb(50,210,80));
        seedView.setPadding(0,0,0,0);
        seedView.setGravity(Gravity.CENTER);
        peersView.addView(seedView,new LinearLayout.LayoutParams(0,-2,1));
        View separator=new View(this);
        separator.setBackgroundColor(Color.rgb(110,110,110));
        peersView.addView(separator,new LinearLayout.LayoutParams(dp(1),dp(20)));
        TextView leechView=cell(leech,12,true,Color.rgb(240,65,65));
        leechView.setPadding(0,0,0,0);
        leechView.setGravity(Gravity.CENTER);
        peersView.addView(leechView,new LinearLayout.LayoutParams(0,-2,1));
        row.addView(peersView,new LinearLayout.LayoutParams(0,dp(66),10));

        View line=new View(this);line.setBackgroundColor(Color.DKGRAY);
        tableRows.addView(row);
        tableRows.addView(line,new LinearLayout.LayoutParams(-1,dp(1)));
        row.setOnClickListener(v->{row.setBackgroundColor(RED);showDetail(url,title,true);});
    }
    private int[] categoryIcons(){
        return new int[]{R.drawable.category_0,R.drawable.category_1,R.drawable.category_2,
            R.drawable.category_3,R.drawable.category_4,R.drawable.category_5,
            R.drawable.category_6,R.drawable.category_7,R.drawable.category_8};
    }
    private ArrayAdapter<String> categoryAdapter(String[] labels){
        final int[] icons=categoryIcons();
        return new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,labels){
            @Override public View getView(int position,View convertView,android.view.ViewGroup parent){
                return categoryRow(labels[position],icons[position],false);
            }
            @Override public View getDropDownView(int position,View convertView,android.view.ViewGroup parent){
                return categoryRow(labels[position],icons[position],true);
            }
        };
    }
    private View categoryRow(String label,int iconId,boolean dropdown){
        LinearLayout row=new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setBackgroundColor(Color.rgb(48,48,48));
        row.setPadding(dp(12),dp(dropdown?7:4),dp(12),dp(dropdown?7:4));
        ImageView icon=new ImageView(this);
        icon.setImageResource(iconId);
        icon.setScaleType(ImageView.ScaleType.FIT_CENTER);
        row.addView(icon,new LinearLayout.LayoutParams(dp(38),dp(38)));
        TextView title=text(label,16,false);
        title.setTextColor(Color.WHITE);
        title.setPadding(dp(13),0,dp(8),0);
        row.addView(title,new LinearLayout.LayoutParams(-1,-2));
        return row;
    }
    private void showDomainDialog(){
        final EditText field=new EditText(this);
        field.setSingleLine(true);
        field.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_URI);
        field.setText(BASE);
        field.setSelectAllOnFocus(true);
        field.setTextColor(Color.WHITE);
        field.setHint("https://rutor.is");
        LinearLayout wrapper=new LinearLayout(this);
        wrapper.setPadding(dp(18),dp(5),dp(18),0);
        wrapper.addView(field,new LinearLayout.LayoutParams(-1,-2));
        AlertDialog dialog=new AlertDialog.Builder(this)
            .setTitle("Домен RUTOR")
            .setMessage("Введите адрес зеркала сайта. Используйте HTTPS.")
            .setView(wrapper)
            .setPositiveButton("Сохранить",null)
            .setNeutralButton("По умолчанию",null)
            .setNegativeButton("Отмена",null).create();
        dialog.setOnShowListener(ignored->{
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
                String input=field.getText().toString().trim();
                if(!input.contains("://"))input="https://"+input;
                try{
                    android.net.Uri parsed=android.net.Uri.parse(input);
                    String host=parsed.getHost();
                    if(!"https".equalsIgnoreCase(parsed.getScheme()) || host==null || host.trim().isEmpty()
                        || host.contains(" ") || host.contains("/") || parsed.getUserInfo()!=null
                        || (parsed.getPath()!=null&&!parsed.getPath().isEmpty()&&!parsed.getPath().equals("/"))
                        || parsed.getQuery()!=null || parsed.getFragment()!=null){
                        field.setError("Введите HTTPS-домен без пути, например https://rutor.is");
                        return;
                    }
                    setSiteDomain("https://"+host.toLowerCase(Locale.ROOT)+(parsed.getPort()>0?":"+parsed.getPort():""));
                    dialog.dismiss();
                }catch(Exception ex){field.setError("Некорректный адрес сайта");}
            });
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v->{
                setSiteDomain(DEFAULT_BASE);dialog.dismiss();
            });
        });
        dialog.show();
    }
    private void setSiteDomain(String domain){
        BASE=domain;
        prefs.edit().putString("site_domain",BASE).apply();
        currentCategory="0";currentQuery="";dateFrom="";dateTo="";
        history.clear();
        showList(BASE,false);
    }
    private void categoryDialog(){
        String[] labels={"Все категории","Зарубежные фильмы","Наши фильмы","Сериалы","Мультфильмы","Музыка","Игры","Программы","Книги"};
        String[] ids={"0","1","5","4","7","2","8","9","11"};
        android.widget.ListView categoryList=new android.widget.ListView(this);
        categoryList.setAdapter(categoryAdapter(labels));
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("Категории RUTOR")
          .setView(categoryList).setNegativeButton("Отмена",null).create();
        categoryList.setOnItemClickListener((parent,view,index,rowId)->{
            dialog.dismiss();
            currentCategory=ids[index];currentQuery="";
            showList(BASE+"/browse/0/"+ids[index]+"/0/0",false);
        });
        dialog.show();
    }
    private String categoryName(String id){
        String[] names={"Все категории","Зарубежные фильмы","Наши фильмы","Сериалы","Мультфильмы","Музыка","Игры","Программы","Книги"};
        String[] ids={"0","1","5","4","7","2","8","9","11"};
        for(int i=0;i<ids.length;i++)if(ids[i].equals(id))return names[i];
        return "Раздачи";
    }
    private void performSearch(String query){
        currentQuery=query;
        showList(BASE+"/search/0/"+currentCategory+"/100/2/"+android.net.Uri.encode(query),false);
    }
    private void addSection(LinearLayout target,String title){
        TextView t=text(title,18,true);t.setTextColor(YELLOW);
        t.setPadding(dp(8),dp(15),dp(8),dp(7));target.addView(t);
        View line=new View(this);line.setBackgroundColor(RED);target.addView(line,new LinearLayout.LayoutParams(-1,dp(2)));
    }
    private void addAction(LinearLayout target,String label,String url,int color){
        if(url==null||url.isEmpty())return;
        TextView t=text(label,16,true);t.setGravity(Gravity.CENTER);t.setBackgroundColor(color);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(50));lp.setMargins(0,dp(5),0,dp(5));target.addView(t,lp);
        t.setOnClickListener(v->openLink(url));
    }
    private void addSplitDownloadAction(LinearLayout target,String torrent,String magnet){
        LinearLayout buttons=new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams outer=new LinearLayout.LayoutParams(-1,dp(52));
        outer.setMargins(0,dp(12),0,dp(8));
        target.addView(buttons,outer);
        addSplitButton(buttons,"⬇ .torrent",torrent,RED,true);
        addSplitButton(buttons,"🧲 Magnet",magnet,Color.rgb(0,115,30),false);
    }
    private void addSplitButton(LinearLayout row,String label,String url,int color,boolean first){
        TextView button=text(label,15,true);
        button.setGravity(Gravity.CENTER);
        button.setTextColor(Color.WHITE);
        button.setBackgroundColor(url==null||url.isEmpty()?Color.DKGRAY:color);
        LinearLayout.LayoutParams params=new LinearLayout.LayoutParams(0,-1,1);
        if(first)params.setMargins(0,0,dp(2),0);
        else params.setMargins(dp(2),0,0,0);
        row.addView(button,params);
        if(url!=null&&!url.isEmpty())button.setOnClickListener(v->openLink(url));
    }
    private String cleanDescription(Element source){
        if(source==null)return "Описание отсутствует";
        Element copy=source.clone();
        copy.select("script,style,iframe,form,nav,footer,header,svg,button,input").remove();
        // Screenshot anchors and thumbnails are presented separately, not as raw markup.
        for(Element a:copy.select("a[href]")){
            String h=a.attr("href").toLowerCase(Locale.ROOT);
            if(h.contains("fastpic")||h.matches(".*\\.(jpg|jpeg|png|webp)(\\?.*)?$"))a.remove();
        }
        copy.select("img,table").remove();
        for(Element e:copy.select("br,p,div,li,h1,h2,h3"))e.prependText("\n");
        String t=org.jsoup.parser.Parser.unescapeEntities(copy.wholeText(),false)
          .replace('\u00a0',' ').replaceAll("[ \t]+"," ").replaceAll("\n[ \t]+","\n")
          .replaceAll("\n[ \t]*\n+","\n").trim();
        t=t.replaceAll("(?i)https?://[^\\s<>]+(?:jpg|jpeg|png|webp)(?:\\.html)?","")
           .replaceAll("(?i)<[^>]{1,300}>","")
           .replaceAll("(?m)^[ \t]*(?:Скрины|Скриншоты)[ \t]*$","").trim();
        if(t.length()>6500)t=t.substring(0,6500)+"…";
        return t.isEmpty()?"Описание отсутствует":t;
    }
    // Split release description into reader-facing details and collapsible technical metadata.
    private String[] splitDescription(String description){
        StringBuilder primary=new StringBuilder(), technical=new StringBuilder();
        boolean inTechnical=false;
        for(String raw:description.split("\\n")){
            String line=raw.trim();
            if(line.isEmpty())continue;
            String lower=line.toLowerCase(Locale.ROOT);
            boolean technicalLabel=lower.matches("^(?:файл|формат|качество|видео|аудио|звук|перевод(?:\\s*\\d+)?|субтитры|кодек|размер|битрейт|частота|разрешение|контейнер|релиз|дорожка|скриншоты|mediainfo|general|video|audio|text|complete name|writing application|duration|overall bit rate|frame rate|width|height|language|format profile|codec id|битность|каналы|раздача|источник)\\s*[:：].*")
                ||lower.matches("^(?:файл|mediainfo|видео|аудио|субтитры|технические данные|скриншоты)$");
            boolean narrativeLabel=lower.matches("^(?:название|оригинальное название|год выпуска|год|жанр|режисс[её]р|в ролях|акт[её]ры|описание|сюжет|страна|продолжительность)\\s*[:：].*")
                ||lower.matches("^(?:описание|сюжет|информация о фильме)$");
            if(technicalLabel)inTechnical=true;
            else if(narrativeLabel)inTechnical=false;
            StringBuilder out=inTechnical?technical:primary;
            if(out.length()>0)out.append('\n');
            out.append(line);
        }
        return new String[]{primary.toString(),technical.toString()};
    }
    private TextView compactText(String value){
        TextView t=text(value,14,false);
        t.setPadding(dp(9),dp(5),dp(9),dp(5));
        t.setIncludeFontPadding(false);
        t.setLineSpacing(0f,1.0f);
        return t;
    }
    private LinearLayout spoiler(LinearLayout target,String label){
        LinearLayout wrap=new LinearLayout(this);wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setBackground(shape());
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(5),0,dp(5));target.addView(wrap,lp);
        TextView toggle=text("▸  "+label,15,true);toggle.setTextColor(YELLOW);
        toggle.setPadding(dp(10),dp(11),dp(10),dp(11));wrap.addView(toggle);
        LinearLayout inner=new LinearLayout(this);inner.setOrientation(LinearLayout.VERTICAL);
        inner.setVisibility(View.GONE);wrap.addView(inner);
        toggle.setOnClickListener(v->{boolean opening=inner.getVisibility()!=View.VISIBLE;
            inner.setVisibility(opening?View.VISIBLE:View.GONE);
            toggle.setText((opening?"▾  ":"▸  ")+label);
        });
        return inner;
    }
    private ArrayList<String> extractImages(Element source){
        LinkedHashSet<String> links=new LinkedHashSet<>();
        for(Element img:source.select("img[src],img[data-src],img[data-original]")){
            String u=img.hasAttr("data-src")?img.absUrl("data-src"):img.hasAttr("data-original")?img.absUrl("data-original"):img.absUrl("src");
            if(usefulImage(u,img))links.add(u);
        }
        // Rutor descriptions may contain escaped image markup inside text nodes.
        String html=org.jsoup.parser.Parser.unescapeEntities(source.html(),false).replace("&quot;","\"");
        java.util.regex.Matcher m=java.util.regex.Pattern.compile("(?i)(?:src|data-src)\\s*=\\s*['\"](https?://[^'\"\\s<>]+\\.(?:jpg|jpeg|png|webp))").matcher(html);
        while(m.find())links.add(m.group(1));
        ArrayList<String> result=new ArrayList<>();
        for(String u:links){if(result.size()>=8)break;result.add(u);}
        return result;
    }
    private boolean usefulImage(String url,Element img){
        if(!url.startsWith("http"))return false;
        String lower=url.toLowerCase(Locale.ROOT);
        if(lower.contains("magnet")||lower.contains("logo")||lower.contains("button")||lower.contains("icon")||lower.contains("rating")||lower.contains("counter")||lower.contains("favicon")||lower.endsWith(".gif"))return false;
        String w=img.attr("width"),h=img.attr("height");
        try{if(!w.isEmpty()&&Integer.parseInt(w.replaceAll("[^0-9]",""))<75)return false;
            if(!h.isEmpty()&&Integer.parseInt(h.replaceAll("[^0-9]",""))<75)return false;}catch(Exception ignored){}
        return true;
    }
    private void addPosterImage(LinearLayout target,String url,String releaseTitle){
        // Size the border from the actual bitmap aspect ratio, not the full screen width.
        ImageView poster=new ImageView(this);
        poster.setScaleType(ImageView.ScaleType.FIT_CENTER);
        poster.setAdjustViewBounds(true);
        poster.setMaxHeight(dp(420));
        int available=getResources().getDisplayMetrics().widthPixels-dp(36);
        poster.setMaxWidth(available);
        GradientDrawable border=new GradientDrawable();
        border.setColor(Color.rgb(19,19,19));
        border.setCornerRadius(dp(13));
        // Modern Blu-ray-inspired outline, without any logo or plastic-case effect.
        // Film/series releases use cyan; other categories keep the gold accent.
        String lowerTitle=releaseTitle.toLowerCase(Locale.ROOT);
        boolean isFilmOrSeries=lowerTitle.matches("(?s).*(web.dl|webrip|bdrip|bdremux|bluray|blu.ray|hdtv|dvdrip|hdrip|1080p|720p|2160p|сериал|фильм).*")
            && !(lowerTitle.contains("mp3")||lowerTitle.contains("flac")||lowerTitle.contains("fb2")||lowerTitle.contains("epub")||lowerTitle.contains("аудиокниг"));
        int outline=isFilmOrSeries?Color.rgb(0,185,245):Color.rgb(205,163,0);
        border.setStroke(dp(2),outline);
        poster.setBackground(border);
        // Clip the bitmap to the same rounded outline as the border.
        poster.setClipToOutline(true);
        poster.setPadding(dp(3),dp(3),dp(3),dp(3));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-2,-2);
        lp.gravity=Gravity.CENTER_HORIZONTAL;
        lp.setMargins(dp(5),dp(6),dp(5),dp(10));
        target.addView(poster,lp);
        pool.execute(()->{try{
            java.net.HttpURLConnection conn=(java.net.HttpURLConnection)new java.net.URL(url).openConnection();
            conn.setConnectTimeout(9000);conn.setReadTimeout(9000);
            conn.setRequestProperty("User-Agent","Mozilla/5.0");
            android.graphics.BitmapFactory.Options opt=new android.graphics.BitmapFactory.Options();
            opt.inSampleSize=2;
            android.graphics.Bitmap bitmap=android.graphics.BitmapFactory.decodeStream(conn.getInputStream(),null,opt);
            conn.disconnect();
            if(bitmap!=null)runOnUiThread(()->{
                if(poster.getParent()==null)return;
                // Explicit dimensions prevent FIT_CENTER from leaving empty side gutters.
                int innerWidth=Math.min(available-dp(6),
                    Math.round((float)bitmap.getWidth()*dp(420)/Math.max(1,bitmap.getHeight())));
                int innerHeight=Math.min(dp(420),
                    Math.round((float)bitmap.getHeight()*innerWidth/Math.max(1,bitmap.getWidth())));
                LinearLayout.LayoutParams fitted=(LinearLayout.LayoutParams)poster.getLayoutParams();
                fitted.width=innerWidth+dp(6);
                fitted.height=innerHeight+dp(6);
                poster.setLayoutParams(fitted);
                poster.setImageBitmap(bitmap);
            });
        }catch(Exception ignored){} });
    }
    private void addRemoteImage(LinearLayout target,String url,int maxHeight){
        ImageView view=new ImageView(this);view.setAdjustViewBounds(true);
        view.setScaleType(ImageView.ScaleType.FIT_CENTER);view.setMaxHeight(dp(maxHeight));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(dp(6),dp(8),dp(6),dp(8));target.addView(view,lp);
        pool.execute(()->{try{
            java.net.HttpURLConnection conn=(java.net.HttpURLConnection)new java.net.URL(url).openConnection();
            conn.setConnectTimeout(9000);conn.setReadTimeout(9000);conn.setRequestProperty("User-Agent","Mozilla/5.0");
            android.graphics.BitmapFactory.Options opt=new android.graphics.BitmapFactory.Options();opt.inSampleSize=2;
            android.graphics.Bitmap bitmap=android.graphics.BitmapFactory.decodeStream(conn.getInputStream(),null,opt);
            conn.disconnect();if(bitmap!=null)runOnUiThread(()->{if(view.getParent()!=null)view.setImageBitmap(bitmap);});
        }catch(Exception ignored){}});
    }
    private ArrayList<String[]> extractComments(Document doc){
        ArrayList<String[]> results=new ArrayList<>();
        // RUTOR comments use table rows with class c_h* for the comment header.
        // The previous parser missed these rows entirely.
        for(Element header:doc.select("tr[class^=c_h], tr[class*=c_h], .c_h")){
            if(results.size()>=100)break;
            Element tableRow=header.tagName().equalsIgnoreCase("tr")?header:header.closest("tr");
            if(tableRow==null)continue;
            String headerText=tableRow.text().trim();
            if(headerText.isEmpty())continue;
            Element user=tableRow.selectFirst("a[href*=profile], a[href*=user], a[href*=login], b, strong");
            String author=user==null?headerText.split("\\|")[0].trim():user.text().trim();
            if(author.length()>70)author=author.substring(0,70);
            if(author.isEmpty())author="Пользователь";
            String bodyText="";
            Element next=tableRow.nextElementSibling();
            if(next!=null&&!next.className().startsWith("c_h")){
                bodyText=cleanComment(next);
            }
            // Sometimes the header and text are in a nested table.
            if(bodyText.isEmpty()&&tableRow.parent()!=null){
                Element outer=tableRow.parent().parent();
                if(outer!=null){
                    Element after=outer.nextElementSibling();
                    if(after!=null)bodyText=cleanComment(after);
                }
            }
            if(bodyText.length()<2)continue;
            results.add(new String[]{author+"  ·  "+headerText.replace(author,"").trim(),bodyText});
        }
        if(!results.isEmpty())return results;
        // RUTOR has used several layouts; search comment blocks, rows and anchors.
        Elements blocks=doc.select("#comments .comment, #comments .com, #comments .comment-item, #comments .message, #comments > div, #comments tr, .comments .comment, .comments > div, #commentlist > div, #comments-list > div, [id^=comment_] ");
        for(Element block:blocks){
            if(results.size()>=100)break;
            if(block.select(".comment, .com, .comment-item, .message, tr").size()>0)continue;
            String body=cleanComment(block);
            if(body.length()<3)continue;
            Element user=block.selectFirst(".username, .author, .user, .nick, a[href*=profile], a[href*=user]");
            String author=user==null?"Пользователь":user.text().trim();
            if(author.length()>65)author=author.substring(0,65);
            if(author.isEmpty())author="Пользователь";
            results.add(new String[]{author,body});
        }
        if(!results.isEmpty())return results;
        // Some layouts place comments in the table immediately after the heading.
        Element heading=null;
        for(Element e:doc.select("h2,h3,h4,b,strong,th,td,div")){
            String t=e.ownText().trim();
            if(t.matches("(?iu)^Комментарии(?:\\s*\\(\\d+\\))?:?$")){heading=e;break;}
        }
        if(heading!=null){
            Element section=heading.nextElementSibling();
            if(section==null&&heading.parent()!=null)section=heading.parent().nextElementSibling();
            if(section!=null){
                Elements rows=section.select("tr, .comment, .message, li");
                if(rows.isEmpty())rows=new Elements(section);
                for(Element row:rows){
                    if(results.size()>=100)break;
                    String t=cleanComment(row);
                    if(t.length()>5&&!t.toLowerCase(Locale.ROOT).contains("добавить комментарий"))
                        results.add(new String[]{"Комментарий",t});
                }
            }
        }
        return results;
    }
    private String cleanComment(Element source){
        Element copy=source.clone();
        copy.select("script,style,iframe,form,button,input,textarea,img,svg").remove();
        for(Element e:copy.select("br,p,div,li"))e.prependText("\n");
        String value=org.jsoup.parser.Parser.unescapeEntities(copy.wholeText(),false)
          .replace('\u00a0',' ').replaceAll("[ \\t]+"," ").replaceAll("\\n[ \\t]+","\\n").trim();
        if(value.length()>2500)value=value.substring(0,2500)+"…";
        return value;
    }
    // Ratings: Cinemeta public catalogue provides IMDb scores. TMDB and
    // Kinopoisk require user-supplied API credentials; never invent ratings.
    private String[] movieNameYear(String title){
        java.util.regex.Matcher m=java.util.regex.Pattern.compile("\\((19[0-9]{2}|20[0-9]{2})\\)").matcher(title);
        String year=m.find()?m.group(1):"";
        String name=title.split("\\s*[\\[(](?:19|20)[0-9]{2}")[0].trim();
        String[] variants=name.split("\\s*/\\s*");
        name=variants.length>1?variants[variants.length-1].trim():name;
        return new String[]{name,year};
    }
    private JSONObject jsonGet(String url, String headerName, String headerValue)throws Exception{
        java.net.HttpURLConnection c=(java.net.HttpURLConnection)new URL(url).openConnection();
        c.setConnectTimeout(9000);c.setReadTimeout(9000);
        c.setRequestProperty("User-Agent","RutorAndroid/2.34");
        if(headerName!=null)c.setRequestProperty(headerName,headerValue);
        try(InputStream in=c.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream()){
            byte[] buf=new byte[4096];int n;while((n=in.read(buf))!=-1)out.write(buf,0,n);
            return new JSONObject(out.toString("UTF-8"));
        }finally{c.disconnect();}
    }
    private String fmtRating(double d){return d>0&&d<=10?String.format(java.util.Locale.US,"%.1f",d):"";}
    private void loadRatings(String title, TextView target){
        String[] parsed=movieNameYear(title);String name=parsed[0],year=parsed[1];
        if(name.isEmpty()){target.setVisibility(View.GONE);return;}
        pool.execute(()->{
            String imdb="",tmdb="",kp="";
            String imdbId="";
            try{
                String q=java.net.URLEncoder.encode(name,"UTF-8");
                JSONObject j=jsonGet("https://v3-cinemeta.strem.io/catalog/movie/top/search="+q+".json",null,null);
                JSONArray metas=j.optJSONArray("metas");
                if(metas!=null)for(int i=0;i<Math.min(metas.length(),15);i++){
                    JSONObject item=metas.optJSONObject(i);if(item==null)continue;
                    String found=item.optString("name","");String foundYear=item.optString("releaseInfo","");
                    if(!found.equalsIgnoreCase(name)||(!year.isEmpty()&&!foundYear.startsWith(year)))continue;
                    imdb=fmtRating(item.optDouble("imdbRating",0));imdbId=item.optString("imdb_id",item.optString("id",""));break;
                }
            }catch(Exception ignored){}
            String tmdbKey=prefs.getString("tmdb_api_key","").trim();
            if(!tmdbKey.isEmpty())try{
                String query="https://api.themoviedb.org/3/search/movie?api_key="+java.net.URLEncoder.encode(tmdbKey,"UTF-8")+"&query="+java.net.URLEncoder.encode(name,"UTF-8")+(year.isEmpty()?"":"&year="+year);
                JSONArray results=jsonGet(query,null,null).optJSONArray("results");
                if(results!=null)for(int i=0;i<Math.min(results.length(),8);i++){
                    JSONObject item=results.optJSONObject(i);if(item==null)continue;
                    String found=item.optString("title","");String date=item.optString("release_date","");
                    if(!found.equalsIgnoreCase(name)||(!year.isEmpty()&&!date.startsWith(year)))continue;
                    tmdb=fmtRating(item.optDouble("vote_average",0));break;
                }
            }catch(Exception ignored){}
            String kpKey=prefs.getString("kp_api_key","").trim();
            if(!kpKey.isEmpty())try{
                String query="https://api.kinopoisk.dev/v1.4/movie/search?page=1&limit=10&query="+java.net.URLEncoder.encode(name,"UTF-8");
                JSONArray docs=jsonGet(query,"X-API-KEY",kpKey).optJSONArray("docs");
                if(docs!=null)for(int i=0;i<Math.min(docs.length(),10);i++){
                    JSONObject item=docs.optJSONObject(i);if(item==null)continue;
                    String ru=item.optString("name","");String en=item.optString("alternativeName","");
                    if(!(name.equalsIgnoreCase(ru)||name.equalsIgnoreCase(en))||(!year.isEmpty()&&item.optInt("year",0)!=Integer.parseInt(year)))continue;
                    JSONObject rating=item.optJSONObject("rating");if(rating!=null)kp=fmtRating(rating.optDouble("kp",0));break;
                }
            }catch(Exception ignored){}
            final String a=imdb,b=kp,c=tmdb;
            runOnUiThread(()->{
                if(!screen.equals("detail")||!currentTitle.equals(title))return;
                StringBuilder line=new StringBuilder();
                if(!a.isEmpty())line.append("★ IMDb ").append(a);
                if(!b.isEmpty()){if(line.length()>0)line.append("    ·    ");line.append("КП ").append(b);}
                if(!c.isEmpty()){if(line.length()>0)line.append("    ·    ");line.append("TMDB ").append(c);}
                if(line.length()==0){target.setText("Рейтинги недоступны · Настроить источники");target.setTextColor(Color.GRAY);}
                else{target.setText(line.toString());target.setTextColor(Color.rgb(255,214,0));}
            });
        });
    }
    private void showRatingsSettings(){
        LinearLayout fields=new LinearLayout(this);fields.setOrientation(LinearLayout.VERTICAL);fields.setPadding(dp(20),dp(8),dp(20),0);
        TextView info=text("IMDb — без ключа. Для TMDB и Кинопоиска укажи собственные API-ключи. Они хранятся только на устройстве.",13,false);fields.addView(info);
        EditText tmdb=new EditText(this);tmdb.setSingleLine(true);tmdb.setHint("API-ключ TMDB");tmdb.setText(prefs.getString("tmdb_api_key",""));fields.addView(tmdb);
        EditText kp=new EditText(this);kp.setSingleLine(true);kp.setHint("API-ключ Kinopoisk.dev");kp.setText(prefs.getString("kp_api_key",""));fields.addView(kp);
        new AlertDialog.Builder(this).setTitle("Источники рейтингов").setView(fields).setNegativeButton("Отмена",null).setPositiveButton("Сохранить",(d,w)->{
            prefs.edit().putString("tmdb_api_key",tmdb.getText().toString().trim()).putString("kp_api_key",kp.getText().toString().trim()).apply();
            showDetail(currentUrl,currentTitle,false);
        }).show();
    }
    private void showDetail(String url,String title,boolean addHistory){
        screen="detail";currentUrl=url;currentTitle=title;init("");
        // Detail screen has no visible toolbar: Android system Back remains active.
        root.removeView(bar);
        LinearLayout content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);body.addView(content);
        content.addView(text("Загрузка раздачи…",15,false));
        pool.execute(()->{try{
            Document doc=Jsoup.connect(url).userAgent("Mozilla/5.0 (Android; Mobile) Chrome/120.0").timeout(18000).get();
            Element desc=doc.selectFirst("#details, .torrent-description, #content, #index");if(desc==null)desc=doc.body();
            Element contentSource=desc;
            Element torrentBlock=doc.selectFirst("#details");if(torrentBlock!=null)contentSource=torrentBlock;
            String description=cleanDescription(contentSource);
            ArrayList<String> imgs=new ArrayList<>();
            imgs.addAll(extractImages(contentSource));
            String torrent=null,magnet=null;
            for(Element a:doc.select("a[href]")){
                String href=a.absUrl("href");String label=a.text().toLowerCase(Locale.ROOT);
                if(magnet==null&&href.startsWith("magnet:"))magnet=href;
                if(torrent==null&&(href.matches("(?i).*\\.torrent(\\?.*)?$")||href.contains("/download/")||label.contains("скачать торрент")))torrent=href;
            }
            ArrayList<String[]> commentItems=extractComments(doc);
            String commentsPage=url;
            String tor=torrent,mag=magnet;
            runOnUiThread(()->{
                if(!screen.equals("detail")||!currentUrl.equals(url))return;
                content.removeAllViews();
                if(!imgs.isEmpty()){
                    addPosterImage(content,imgs.get(0),title);
                }else content.addView(text("Постер не найден на странице раздачи",13,false));
                TextView heading=text(org.jsoup.parser.Parser.unescapeEntities(title,false),13,true);
                heading.setTypeface(android.graphics.Typeface.DEFAULT,android.graphics.Typeface.BOLD);
                heading.getPaint().setFakeBoldText(true);
                heading.setTextColor(Color.BLACK);
                heading.setBackgroundColor(YELLOW);
                heading.setPadding(dp(10),dp(5),dp(10),dp(5));
                heading.setIncludeFontPadding(false);
                LinearLayout.LayoutParams headingParams=new LinearLayout.LayoutParams(-1,-2);
                headingParams.setMargins(dp(5),0,dp(5),dp(8));
                content.addView(heading,headingParams);
                TextView ratingLine=text("★ Загрузка рейтингов…",12,false);
                ratingLine.setTextColor(Color.rgb(255,214,0));
                ratingLine.setPadding(dp(12),dp(3),dp(8),dp(6));
                ratingLine.setSingleLine(true);
                ratingLine.setEllipsize(TextUtils.TruncateAt.END);
                content.addView(ratingLine,new LinearLayout.LayoutParams(-1,-2));
                ratingLine.setOnClickListener(v->showRatingsSettings());
                ratingLine.setOnLongClickListener(v->{showRatingsSettings();return true;});
                loadRatings(title,ratingLine);
                LinearLayout descriptionPanel=spoiler(content,"Описание раздачи");
                String[] parts=splitDescription(description);
                descriptionPanel.addView(compactText(parts[0].isEmpty()?"Описание отсутствует":parts[0]));
                LinearLayout technical=spoiler(content,"Техническая информация");
                technical.addView(compactText(parts[1].isEmpty()?"Техническая информация отсутствует":parts[1]));
                LinearLayout gallery=spoiler(content,"Скриншоты и другие изображения ("+Math.max(0,imgs.size()-1)+")");
                if(imgs.size()>1){
                    for(int i=1;i<imgs.size();i++)addRemoteImage(gallery,imgs.get(i),340);
                }else gallery.addView(compactText("Дополнительные изображения отсутствуют"));
                addSplitDownloadAction(content,tor,mag);
                addSection(content,"Комментарии ("+commentItems.size()+")");
                if(commentItems.isEmpty()){
                    content.addView(compactText("Комментарии не найдены в HTML страницы. Они могут загружаться сайтом отдельно."));
                }else{
                    for(String[] item:commentItems){
                        LinearLayout commentCard=new LinearLayout(this);
                        commentCard.setOrientation(LinearLayout.VERTICAL);
                        commentCard.setBackgroundColor(Color.rgb(20,29,52));
                        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);
                        cp.setMargins(dp(4),dp(7),dp(4),dp(13));
                        content.addView(commentCard,cp);

                        LinearLayout commentHeader=new LinearLayout(this);
                        commentHeader.setOrientation(LinearLayout.HORIZONTAL);
                        commentHeader.setGravity(android.view.Gravity.CENTER_VERTICAL);
                        commentHeader.setBackgroundColor(Color.rgb(10,26,70));
                        commentHeader.setPadding(dp(9),dp(7),dp(9),dp(7));
                        commentCard.addView(commentHeader,new LinearLayout.LayoutParams(-1,-2));

                        String headerValue=item[0];
                        String authorName=headerValue;
                        String dateValue="";
                        int separator=headerValue.indexOf("  ·  ");
                        if(separator>=0){
                            authorName=headerValue.substring(0,separator).trim();
                            dateValue=headerValue.substring(separator+5).trim();
                        }
                        TextView author=text(authorName,13,true);
                        author.setTextColor(Color.WHITE);
                        commentHeader.addView(author,new LinearLayout.LayoutParams(0,-2,1f));
                        if(!dateValue.isEmpty()){
                            // Keep the exact timestamp; the verbose relative age
                            // would force the header to wrap on narrow phones.
                            String compactDate=dateValue.replaceFirst("\\s*\\([^)]*\\)\\s*$","").trim();
                            TextView date=text(compactDate,10,false);
                            date.setTextColor(Color.rgb(218,224,240));
                            date.setGravity(android.view.Gravity.RIGHT|android.view.Gravity.CENTER_VERTICAL);
                            date.setSingleLine(true);
                            date.setEllipsize(android.text.TextUtils.TruncateAt.END);
                            date.setIncludeFontPadding(false);
                            LinearLayout.LayoutParams dateLp=new LinearLayout.LayoutParams(-2,-2);
                            dateLp.leftMargin=dp(8);
                            commentHeader.addView(date,dateLp);
                        }

                        TextView message=text(item[1],14,false);
                        message.setTextColor(Color.rgb(240,243,249));
                        message.setPadding(dp(9),dp(9),dp(9),dp(11));
                        message.setLineSpacing(dp(2),1.0f);
                        commentCard.addView(message,new LinearLayout.LayoutParams(-1,-2));
                    }
                }
                TextView browserComments=text("↗ Открыть комментарии на сайте",13,true);
                browserComments.setTextColor(YELLOW);
                browserComments.setPadding(dp(10),dp(12),dp(10),dp(14));
                content.addView(browserComments);
                browserComments.setOnClickListener(v->openLink(commentsPage));
            });
        }catch(Exception e){runOnUiThread(()->{if(screen.equals("detail")&&currentUrl.equals(url)){
            content.removeAllViews();content.addView(text("Ошибка загрузки: "+e.getMessage(),15,false));}});}});
    }
    private void openLink(String url){try{Intent i=new Intent(Intent.ACTION_VIEW,android.net.Uri.parse(url));startActivity(i);}catch(Exception e){Toast.makeText(this,"Нет приложения для открытия ссылки",Toast.LENGTH_LONG).show();}}
    private void goBack(){if(screen.equals("detail")){if(!history.isEmpty()){String[] prev=history.pop().split("\\|",2);showDetail(prev[0],prev.length>1?prev[1]:"Раздача",false);}else showList(listUrl,favoritesMode);}else if(screen.equals("search"))showList(listUrl,favoritesMode);else super.onBackPressed();}
    @Override public void onBackPressed(){goBack();}
    @Override protected void onDestroy(){pool.shutdownNow();super.onDestroy();}
}
