package com.rutor.androidv2;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.*;
import android.text.method.LinkMovementMethod;
import android.view.*;
import android.widget.*;
import org.jsoup.*;
import org.jsoup.nodes.*;
import org.jsoup.select.Elements;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    private static final String BASE = "https://rutor.is";
    private final ExecutorService pool = Executors.newFixedThreadPool(4);
    private final int BG = Color.BLACK, FG = Color.WHITE, ACCENT = Color.rgb(88,200,239);
    private final int YELLOW = Color.rgb(255,220,0), RED = Color.rgb(170,0,0);
    private LinearLayout tableRows;
    private int selectedRow = -1;
    private LinearLayout root, body, bar;
    private String currentUrl = BASE, listUrl = BASE, currentTitle = "", screen = "list";
    private boolean favoritesMode = false;
    private String currentCategory = "0", currentQuery = "";
    private String dateFrom = "", dateTo = "";
    private int sortBy = 0;
    private boolean sortDescending = true;
    private final ArrayDeque<String> history = new ArrayDeque<>();
    private android.content.SharedPreferences prefs;

    @Override public void onCreate(Bundle b) { super.onCreate(b); prefs=getSharedPreferences("rutor",MODE_PRIVATE); showList(BASE,false); }
    private int dp(int n){return (int)(getResources().getDisplayMetrics().density*n+.5f);}
    private TextView text(String s,int size,boolean bold){ TextView t=new TextView(this); t.setText(s);t.setTextColor(FG);t.setTextSize(size); if(bold)t.setTypeface(null,Typeface.BOLD);t.setPadding(dp(12),dp(9),dp(12),dp(9)); return t; }
    private GradientDrawable shape(){GradientDrawable d=new GradientDrawable();d.setColor(Color.rgb(15,15,15));d.setCornerRadius(dp(9));return d;}
    private void init(String title){
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(BG);setContentView(root);
        bar=new LinearLayout(this);bar.setOrientation(LinearLayout.HORIZONTAL);bar.setGravity(Gravity.CENTER_VERTICAL);root.addView(bar);
        if(!screen.equals("list")){TextView back=text("‹",30,true);bar.addView(back);back.setOnClickListener(v->goBack());}
        if(!title.isEmpty()){TextView heading=text(title,20,true);heading.setSingleLine(true);heading.setEllipsize(TextUtils.TruncateAt.END);bar.addView(heading,new LinearLayout.LayoutParams(0,dp(58),1));}
        ScrollView sc=new ScrollView(this);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setPadding(dp(8),dp(4),dp(8),dp(20));sc.addView(body);
    }
    private void notice(String message){body.addView(text(message,15,false));}
    private void load(String url, java.util.function.Consumer<Document> done){
        notice("Загрузка…");pool.execute(()->{
            try {Document doc=Jsoup.connect(url).userAgent("Mozilla/5.0 (Android 14; Mobile) AppleWebKit/537.36 Chrome/120.0 Safari/537.36").timeout(18000).followRedirects(true).get();runOnUiThread(()->{if(!isFinishing()){body.removeAllViews();done.accept(doc);}});}
            catch(Exception e){runOnUiThread(()->{if(!isFinishing()){body.removeAllViews();notice("Не удалось загрузить страницу: "+e.getMessage()+"\nПроверь интернет или доступность rutor.is.");}});}
        });
    }
    private TextView cell(String value,int size,boolean bold,int color){
        TextView t=text(value,size,bold);
        t.setTextColor(color);
        t.setPadding(dp(4),dp(9),dp(4),dp(9));
        t.setGravity(Gravity.CENTER_VERTICAL);
        t.setMaxLines(2);
        t.setEllipsize(TextUtils.TruncateAt.END);
        return t;
    }
    private void tableHeader(){
        // No yellow table header: keep only Categories and Search above releases.
        tableRows=new LinearLayout(this);
        tableRows.setOrientation(LinearLayout.VERTICAL);
        body.addView(tableRows);
    }
    private void tab(LinearLayout parent,String label,boolean active,Runnable action){
        TextView t=cell(label,14,true,active?Color.BLACK:Color.WHITE);
        t.setGravity(Gravity.CENTER);
        GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
          active?new int[]{Color.YELLOW,YELLOW}:new int[]{Color.RED,Color.rgb(90,0,0)});
        d.setCornerRadii(new float[]{dp(7),dp(7),dp(7),dp(7),0,0,0,0});
        t.setBackground(d);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(45),1);
        lp.setMargins(dp(1),0,dp(1),0);
        parent.addView(t,lp);
        t.setOnClickListener(v->action.run());
    }
    private void showList(String url,boolean favorite){
        screen="list";favoritesMode=favorite;listUrl=url;currentUrl=url;selectedRow=-1;
        init("");
        // Two independent actions: categories and full advanced search.
        LinearLayout nav=new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        body.addView(nav,new LinearLayout.LayoutParams(-1,dp(52)));
        TextView categories=cell("Категории ▾",17,true,Color.BLACK);
        categories.setGravity(Gravity.CENTER);
        categories.setBackgroundColor(YELLOW);
        nav.addView(categories,new LinearLayout.LayoutParams(0,-1,1));
        categories.setOnClickListener(v->categoryDialog());
        View separator=new View(this);separator.setBackgroundColor(BG);
        nav.addView(separator,new LinearLayout.LayoutParams(dp(3),-1));
        TextView searchButton=cell("Поиск",17,true,Color.BLACK);
        searchButton.setGravity(Gravity.CENTER);
        searchButton.setBackgroundColor(YELLOW);
        nav.addView(searchButton,new LinearLayout.LayoutParams(0,-1,1));
        searchButton.setOnClickListener(v->showAdvancedSearch());
        if(!currentQuery.isEmpty()||!currentCategory.equals("0")||!dateFrom.isEmpty()||!dateTo.isEmpty()){
            TextView filter=text((!currentQuery.isEmpty()?"Поиск: "+currentQuery:"Категория: "+categoryName(currentCategory))+(dateFrom.isEmpty()&&dateTo.isEmpty()?"":" · "+(dateFrom.isEmpty()?"…":dateFrom)+" — "+(dateTo.isEmpty()?"…":dateTo))+"   ✕",13,false);
            body.addView(filter);
            filter.setOnClickListener(v->{currentCategory="0";currentQuery="";dateFrom="";dateTo="";showList(BASE,false);});
        }
        tableHeader();
        if(favorite){
            Set<String> saved=prefs.getStringSet("favorites",Collections.emptySet());
            if(saved.isEmpty())tableRows.addView(text("Избранное пока пусто",15,false));
            for(String item:saved){int k=item.indexOf('|');
                if(k>0)addItem(item.substring(0,k),item.substring(k+1),"—","—","—");}
            return;
        }
        tableRows.addView(text("Загрузка раздач…",15,false));
        pool.execute(()->{
            try{
                Document doc=Jsoup.connect(url).userAgent("Mozilla/5.0 (Android; Mobile) Chrome/120.0").timeout(18000).get();
                ArrayList<String[]> found=new ArrayList<>();HashSet<String> seen=new HashSet<>();
                for(Element a:doc.select("tr.gai a[href], tr.tum a[href], #index a[href], table a[href]")){
                    String href=a.absUrl("href"),title=a.text().trim();
                    if(href.matches("(?i).*/torrent/\\d+.*")&&title.length()>3&&seen.add(href)){
                        Element tr=a.closest("tr");
                        String date="—",size="—",peers="—";
                        if(tr!=null){
                            Elements td=tr.select("> td");
                            if(td.size()>0)date=td.get(0).text();
                            if(td.size()>2)size=td.get(td.size()-2).text();
                            if(td.size()>3)peers=td.get(td.size()-1).text();
                        }
                        // Hide the three permanent tracker announcements on the home screen.
                        if((title.toLowerCase(Locale.ROOT).contains("новый адрес: rutor")
                            || title.toLowerCase(Locale.ROOT).contains("вечная блокировка в россии")
                            || title.toLowerCase(Locale.ROOT).contains("путеводитель по rutor")))continue;
                        if(dateInRange(date))found.add(new String[]{title,href,date,size,peers});
                    }
                }
                sortResults(found);
                runOnUiThread(()->{
                    if(!screen.equals("list")||favoritesMode||!listUrl.equals(url))return;
                    tableRows.removeAllViews();
                    if(found.isEmpty())tableRows.addView(text("Раздачи не найдены. Проверь поисковый запрос или выбери другую категорию.",15,false));
                    for(String[] pair:found)addItem(pair[0],pair[1],pair[2],pair[3],pair[4]);
                });
            }catch(Exception e){runOnUiThread(()->{
                if(screen.equals("list")&&listUrl.equals(url)){
                    tableRows.removeAllViews();
                    tableRows.addView(text("Ошибка загрузки: "+e.getMessage(),15,false));
                }
            });}
        });
    }
    private void showAdvancedSearch(){
        screen="search";
        init("Расширенный поиск");
        addSection(body,"Расширенный поиск RUTOR");
        EditText query=new EditText(this);
        query.setSingleLine(true);
        query.setTextColor(FG);
        query.setHintTextColor(Color.LTGRAY);
        query.setHint("Название, актёр, год или ключевые слова");
        query.setText(currentQuery);
        query.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH);
        body.addView(query,new LinearLayout.LayoutParams(-1,dp(56)));
        TextView categoryLabel=text("Категория",15,true);
        body.addView(categoryLabel);
        String[] labels={"Все категории","Зарубежные фильмы","Наши фильмы","Сериалы","Мультфильмы","Музыка","Игры","Программы","Книги"};
        String[] ids={"0","1","5","4","7","2","8","9","11"};
        Spinner spinner=new Spinner(this);
        ArrayAdapter<String> adapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,labels);
        spinner.setAdapter(adapter);
        body.addView(spinner,new LinearLayout.LayoutParams(-1,dp(52)));
        for(int i=0;i<ids.length;i++)if(ids[i].equals(currentCategory)){spinner.setSelection(i);break;}
        TextView sortLabel=text("Упорядочить по",15,true);
        body.addView(sortLabel);
        String[] sortLabels={"дате добавления","раздающим","качающим","названию","размеру","релевантности"};
        Spinner sortSpinner=new Spinner(this);
        sortSpinner.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,sortLabels));
        sortSpinner.setSelection(sortBy);
        body.addView(sortSpinner,new LinearLayout.LayoutParams(-1,dp(50)));
        RadioGroup direction=new RadioGroup(this);
        direction.setOrientation(RadioGroup.HORIZONTAL);
        RadioButton ascending=new RadioButton(this);
        ascending.setText("по возрастанию");
        ascending.setTextSize(13);
        RadioButton descending=new RadioButton(this);
        descending.setText("по убыванию");
        descending.setTextSize(13);
        ascending.setId(View.generateViewId());
        descending.setId(View.generateViewId());
        direction.addView(ascending,new RadioGroup.LayoutParams(0,dp(44),1));
        direction.addView(descending,new RadioGroup.LayoutParams(0,dp(44),1));
        direction.check(sortDescending?descending.getId():ascending.getId());
        body.addView(direction);
        TextView dateLabel=text("Отображать по дате",15,true);
        dateLabel.setPadding(dp(8),dp(10),dp(8),dp(3));
        body.addView(dateLabel);
        LinearLayout dateRow=new LinearLayout(this);
        dateRow.setOrientation(LinearLayout.HORIZONTAL);
        dateRow.setGravity(Gravity.CENTER_VERTICAL);
        body.addView(dateRow,new LinearLayout.LayoutParams(-1,dp(55)));
        TextView from=makeDateField("С",dateFrom);
        TextView to=makeDateField("До",dateTo);
        dateRow.addView(from,new LinearLayout.LayoutParams(0,dp(50),1));
        dateRow.addView(to,new LinearLayout.LayoutParams(0,dp(50),1));
        from.setOnClickListener(v->pickDate(from,true));
        to.setOnClickListener(v->pickDate(to,false));
        TextView dateHelp=text("Нажми на поле, чтобы выбрать дату. Пустое поле — без ограничения.",11,false);
        dateHelp.setTextColor(Color.LTGRAY);
        dateHelp.setPadding(dp(8),0,dp(8),dp(5));
        body.addView(dateHelp);
        TextView submit=text("Найти раздачи",17,true);
        submit.setGravity(Gravity.CENTER);
        submit.setBackgroundColor(RED);
        LinearLayout.LayoutParams buttonParams=new LinearLayout.LayoutParams(-1,dp(52));
        buttonParams.setMargins(0,dp(14),0,0);
        body.addView(submit,buttonParams);
        Runnable search=()->{
            String q=query.getText().toString().trim();
            if(!dateFrom.isEmpty()&&!dateTo.isEmpty()&&parseFilterDate(dateFrom)>parseFilterDate(dateTo)){
                Toast.makeText(this,"Дата «С» должна быть раньше даты «До»",Toast.LENGTH_LONG).show();
                return;
            }
            currentCategory=ids[spinner.getSelectedItemPosition()];
            sortBy=sortSpinner.getSelectedItemPosition();
            sortDescending=direction.getCheckedRadioButtonId()!=ascending.getId();
            if(q.isEmpty()){
                currentQuery="";
                showList(BASE+"/browse/0/"+currentCategory+"/0/0",false);
            }else performSearch(q);
        };
        submit.setOnClickListener(v->search.run());
        query.setOnEditorActionListener((v,action,event)->{search.run();return true;});
    }
    private double peerNumber(String peers,int index){
        java.util.regex.Matcher matcher=java.util.regex.Pattern.compile("\\d+").matcher(peers);
        int count=0;
        while(matcher.find()){
            if(count++==index)try{return Double.parseDouble(matcher.group());}catch(Exception ignored){}
        }
        return 0;
    }
    private double sizeBytes(String value){
        java.util.regex.Matcher matcher=java.util.regex.Pattern.compile("([0-9]+(?:[.,][0-9]+)?)\\s*(TB|GB|MB|KB|ТБ|ГБ|МБ|КБ|B)",java.util.regex.Pattern.CASE_INSENSITIVE).matcher(value);
        if(!matcher.find())return 0;
        double n;
        try{n=Double.parseDouble(matcher.group(1).replace(',','.'));}catch(Exception e){return 0;}
        String unit=matcher.group(2).toUpperCase(Locale.ROOT);
        if(unit.equals("TB")||unit.equals("ТБ"))return n*1099511627776d;
        if(unit.equals("GB")||unit.equals("ГБ"))return n*1073741824d;
        if(unit.equals("MB")||unit.equals("МБ"))return n*1048576d;
        if(unit.equals("KB")||unit.equals("КБ"))return n*1024d;
        return n;
    }
    private void sortResults(ArrayList<String[]> results){
        if(sortBy==5)return;
        Collections.sort(results,(a,b)->{
            int comparison=0;
            switch(sortBy){
                case 0: comparison=Long.compare(parseReleaseDate(a[2]),parseReleaseDate(b[2]));break;
                case 1: comparison=Double.compare(peerNumber(a[4],0),peerNumber(b[4],0));break;
                case 2: comparison=Double.compare(peerNumber(a[4],1),peerNumber(b[4],1));break;
                case 3: comparison=a[0].compareToIgnoreCase(b[0]);break;
                case 4: comparison=Double.compare(sizeBytes(a[3]),sizeBytes(b[3]));break;
            }
            return sortDescending?-comparison:comparison;
        });
    }
    private TextView makeDateField(String label,String value){
        TextView field=text(label+": "+(value.isEmpty()?"дд.мм.гггг":value),14,false);
        field.setGravity(Gravity.CENTER);
        field.setTextColor(Color.WHITE);
        GradientDrawable border=shape();
        border.setStroke(dp(1),Color.GRAY);
        field.setBackground(border);
        return field;
    }
    private void pickDate(TextView field,boolean isFrom){
        Calendar c=Calendar.getInstance();
        String existing=isFrom?dateFrom:dateTo;
        if(!existing.isEmpty()){
            String[] parts=existing.split("\\.");
            if(parts.length==3)try{
                c.set(Integer.parseInt(parts[2]),Integer.parseInt(parts[1])-1,Integer.parseInt(parts[0]));
            }catch(NumberFormatException ignored){}
        }
        DatePickerDialog dialog=new DatePickerDialog(this,(picker,year,month,day)->{
            String value=String.format(Locale.ROOT,"%02d.%02d.%04d",day,month+1,year);
            if(isFrom)dateFrom=value;else dateTo=value;
            field.setText((isFrom?"С: ":"До: ")+value);
        },c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH));
        dialog.setButton(android.content.DialogInterface.BUTTON_NEUTRAL,"Очистить",(d,w)->{
            if(isFrom)dateFrom="";else dateTo="";
            field.setText(isFrom?"С: дд.мм.гггг":"До: дд.мм.гггг");
        });
        dialog.show();
    }
    private long parseFilterDate(String value){
        if(value==null||value.isEmpty())return -1;
        try{
            java.text.SimpleDateFormat format=new java.text.SimpleDateFormat("dd.MM.yyyy",Locale.ROOT);
            format.setLenient(false);
            return format.parse(value).getTime();
        }catch(Exception ignored){return -1;}
    }
    private long parseReleaseDate(String value){
        // RUTOR displays dates like "01 Ноя 26" and sometimes "01 Ноя".
        java.util.regex.Matcher m=java.util.regex.Pattern.compile("(\\d{1,2})\\s+([\\p{L}]+)(?:\\s+(\\d{2,4}))?",java.util.regex.Pattern.CASE_INSENSITIVE|java.util.regex.Pattern.UNICODE_CASE).matcher(value);
        if(!m.find())return -1;
        String month=m.group(2).toLowerCase(new Locale("ru"));
        String[] months={"янв","фев","мар","апр","мая","май","июн","июл","авг","сен","сент","окт","ноя","дек"};
        int[] monthIndexes={0,1,2,3,4,4,5,6,7,8,8,9,10,11};
        int idx=-1;
        for(int i=0;i<months.length;i++)if(month.startsWith(months[i])){idx=monthIndexes[i];break;}
        if(idx<0)return -1;
        try{
            int year=m.group(3)==null?Calendar.getInstance().get(Calendar.YEAR):Integer.parseInt(m.group(3));
            if(year<100)year+=2000;
            Calendar c=Calendar.getInstance();
            c.clear();
            c.setLenient(false);
            c.set(year,idx,Integer.parseInt(m.group(1)));
            return c.getTimeInMillis();
        }catch(Exception ignored){return -1;}
    }
    private boolean dateInRange(String releaseDate){
        if(dateFrom.isEmpty()&&dateTo.isEmpty())return true;
        long actual=parseReleaseDate(releaseDate);
        if(actual<0)return false;
        long start=parseFilterDate(dateFrom),end=parseFilterDate(dateTo);
        return (start<0||actual>=start)&&(end<0||actual<=end);
    }
    private void searchDialog(){
        EditText field=new EditText(this);
        field.setSingleLine(true);
        new AlertDialog.Builder(this).setTitle("Поиск RUTOR").setView(field)
          .setPositiveButton("Найти",(d,w)->{
              String q=field.getText().toString().trim();
              if(!q.isEmpty())performSearch(q);
          }).setNegativeButton("Отмена",null).show();
    }
    private void addItem(String title,String url,String date,String size,String peers){
        LinearLayout row=new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setBackgroundColor(tableRows.getChildCount()%2==0?Color.rgb(12,12,12):Color.rgb(27,31,33));

        // The date belongs to the release title, not a separate table column.
        LinearLayout titleColumn=new LinearLayout(this);
        titleColumn.setOrientation(LinearLayout.VERTICAL);
        titleColumn.setPadding(dp(10),dp(3),dp(1),dp(3));
        TextView dateView=text(date.replaceAll("\\s+", " ").trim(),10,false);
        dateView.setTextColor(Color.rgb(190,190,190));
        dateView.setIncludeFontPadding(false);
        dateView.setSingleLine(true);
        titleColumn.addView(dateView);
        TextView nameView=text(title,12,true);
        nameView.setTextColor(Color.WHITE);
        nameView.setIncludeFontPadding(false);
        nameView.setMaxLines(2);
        nameView.setEllipsize(TextUtils.TruncateAt.END);
        nameView.setPadding(0,dp(1),0,0);
        titleColumn.addView(nameView);
        row.addView(titleColumn,new LinearLayout.LayoutParams(0,dp(60),77));

        TextView sizeView=cell(size,12,false,Color.WHITE);
        sizeView.setGravity(Gravity.CENTER);
        row.addView(sizeView,new LinearLayout.LayoutParams(0,dp(60),13));

        // RUTOR peers: seeders first (green), leechers second (red).
        java.util.regex.Matcher numbers=java.util.regex.Pattern.compile("\\d[\\d\\s,]*").matcher(peers);
        String seed="0", leech="0";
        java.util.ArrayList<String> counts=new java.util.ArrayList<>();
        while(numbers.find()){
            for(String part:numbers.group().trim().split("[\\s,]+"))
                if(!part.isEmpty())counts.add(part);
        }
        if(counts.size()>0)seed=counts.get(0);
        if(counts.size()>1)leech=counts.get(1);
        LinearLayout peersView=new LinearLayout(this);
        peersView.setGravity(Gravity.CENTER);
        peersView.setOrientation(LinearLayout.HORIZONTAL);
        TextView seedView=cell(seed,12,true,Color.rgb(50,210,80));
        seedView.setPadding(0,0,0,0);
        seedView.setGravity(Gravity.CENTER);
        peersView.addView(seedView,new LinearLayout.LayoutParams(0,-2,1));
        View separator=new View(this);
        separator.setBackgroundColor(Color.rgb(110,110,110));
        peersView.addView(separator,new LinearLayout.LayoutParams(dp(1),dp(20)));
        TextView leechView=cell(leech,12,true,Color.rgb(240,65,65));
        leechView.setPadding(0,0,0,0);
        leechView.setGravity(Gravity.CENTER);
        peersView.addView(leechView,new LinearLayout.LayoutParams(0,-2,1));
        row.addView(peersView,new LinearLayout.LayoutParams(0,dp(60),10));

        View line=new View(this);line.setBackgroundColor(Color.DKGRAY);
        tableRows.addView(row);
        tableRows.addView(line,new LinearLayout.LayoutParams(-1,dp(1)));
        row.setOnClickListener(v->{row.setBackgroundColor(RED);showDetail(url,title,true);});
    }
    private void categoryDialog(){
        String[] labels={"Все категории","Зарубежные фильмы","Наши фильмы","Сериалы","Мультфильмы","Музыка","Игры","Программы","Книги"};
        String[] ids={"0","1","5","4","7","2","8","9","11"};
        new AlertDialog.Builder(this).setTitle("Категории RUTOR")
          .setItems(labels,(dialog,index)->{currentCategory=ids[index];currentQuery="";showList(BASE+"/browse/0/"+ids[index]+"/0/0",false);})
          .setNegativeButton("Отмена",null).show();
    }
    private String categoryName(String id){
        String[] names={"Все категории","Зарубежные фильмы","Наши фильмы","Сериалы","Мультфильмы","Музыка","Игры","Программы","Книги"};
        String[] ids={"0","1","5","4","7","2","8","9","11"};
        for(int i=0;i<ids.length;i++)if(ids[i].equals(id))return names[i];
        return "Раздачи";
    }
    private void performSearch(String query){
        currentQuery=query;
        showList(BASE+"/search/0/"+currentCategory+"/100/2/"+android.net.Uri.encode(query),false);
    }
    private void addSection(LinearLayout target,String title){
        TextView t=text(title,18,true);t.setTextColor(YELLOW);
        t.setPadding(dp(8),dp(15),dp(8),dp(7));target.addView(t);
        View line=new View(this);line.setBackgroundColor(RED);target.addView(line,new LinearLayout.LayoutParams(-1,dp(2)));
    }
    private void addAction(LinearLayout target,String label,String url,int color){
        if(url==null||url.isEmpty())return;
        TextView t=text(label,16,true);t.setGravity(Gravity.CENTER);t.setBackgroundColor(color);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(50));lp.setMargins(0,dp(5),0,dp(5));target.addView(t,lp);
        t.setOnClickListener(v->openLink(url));
    }
    private void addSplitDownloadAction(LinearLayout target,String torrent,String magnet){
        LinearLayout buttons=new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams outer=new LinearLayout.LayoutParams(-1,dp(52));
        outer.setMargins(0,dp(12),0,dp(8));
        target.addView(buttons,outer);
        addSplitButton(buttons,"⬇ .torrent",torrent,RED,true);
        addSplitButton(buttons,"🧲 Magnet",mag,Color.rgb(0,115,30),false);
    }
    private void addSplitButton(LinearLayout row,String label,String url,int color,boolean first){
        TextView button=text(label,15,true);
        button.setGravity(Gravity.CENTER);
        button.setTextColor(Color.WHITE);
        button.setBackgroundColor(url==null||url.isEmpty()?Color.DKGRAY:color);
        LinearLayout.LayoutParams params=new LinearLayout.LayoutParams(0,-1,1);
        if(first)params.setMargins(0,0,dp(2),0);
        else params.setMargins(dp(2),0,0,0);
        row.addView(button,params);
        if(url!=null&&!url.isEmpty())button.setOnClickListener(v->openLink(url));
    }
    private String cleanDescription(Element source){
        if(source==null)return "Описание отсутствует";
        Element copy=source.clone();
        copy.select("script,style,iframe,form,nav,footer,header,svg,button,input").remove();
        // Screenshot anchors and thumbnails are presented separately, not as raw markup.
        for(Element a:copy.select("a[href]")){
            String h=a.attr("href").toLowerCase(Locale.ROOT);
            if(h.contains("fastpic")||h.matches(".*\\.(jpg|jpeg|png|webp)(\\?.*)?$"))a.remove();
        }
        copy.select("img,table").remove();
        for(Element e:copy.select("br,p,div,li,h1,h2,h3"))e.prependText("\n");
        String t=org.jsoup.parser.Parser.unescapeEntities(copy.wholeText(),false)
          .replace('\u00a0',' ').replaceAll("[ \t]+"," ").replaceAll("\n[ \t]+","\n")
          .replaceAll("\n[ \t]*\n+","\n").trim();
        t=t.replaceAll("(?i)https?://[^\\s<>]+(?:jpg|jpeg|png|webp)(?:\\.html)?","")
           .replaceAll("(?i)<[^>]{1,300}>","")
           .replaceAll("(?m)^[ \t]*(?:Скрины|Скриншоты)[ \t]*$","").trim();
        if(t.length()>6500)t=t.substring(0,6500)+"…";
        return t.isEmpty()?"Описание отсутствует":t;
    }
    // Split release description into reader-facing details and collapsible technical metadata.
    private String[] splitDescription(String description){
        StringBuilder primary=new StringBuilder(), technical=new StringBuilder();
        boolean inTechnical=false;
        for(String raw:description.split("\\n")){
            String line=raw.trim();
            if(line.isEmpty())continue;
            String lower=line.toLowerCase(Locale.ROOT);
            boolean technicalLabel=lower.matches("^(?:файл|формат|качество|видео|аудио|звук|перевод(?:\\s*\\d+)?|субтитры|кодек|размер|битрейт|частота|разрешение|контейнер|релиз|дорожка|скриншоты|mediainfo|general|video|audio|text|complete name|writing application|duration|overall bit rate|frame rate|width|height|language|format profile|codec id|битность|каналы|раздача|источник)\\s*[:：].*")
                ||lower.matches("^(?:файл|mediainfo|видео|аудио|субтитры|технические данные|скриншоты)$");
            boolean narrativeLabel=lower.matches("^(?:название|оригинальное название|год выпуска|год|жанр|режисс[её]р|в ролях|акт[её]ры|описание|сюжет|страна|продолжительность)\\s*[:：].*")
                ||lower.matches("^(?:описание|сюжет|информация о фильме)$");
            if(technicalLabel)inTechnical=true;
            else if(narrativeLabel)inTechnical=false;
            StringBuilder out=inTechnical?technical:primary;
            if(out.length()>0)out.append('\n');
            out.append(line);
        }
        return new String[]{primary.toString(),technical.toString()};
    }
    private TextView compactText(String value){
        TextView t=text(value,14,false);
        t.setPadding(dp(9),dp(5),dp(9),dp(5));
        t.setIncludeFontPadding(false);
        t.setLineSpacing(0f,1.0f);
        return t;
    }
    private LinearLayout spoiler(LinearLayout target,String label){
        LinearLayout wrap=new LinearLayout(this);wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setBackground(shape());
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(5),0,dp(5));target.addView(wrap,lp);
        TextView toggle=text("▸  "+label,15,true);toggle.setTextColor(YELLOW);
        toggle.setPadding(dp(10),dp(11),dp(10),dp(11));wrap.addView(toggle);
        LinearLayout inner=new LinearLayout(this);inner.setOrientation(LinearLayout.VERTICAL);
        inner.setVisibility(View.GONE);wrap.addView(inner);
        toggle.setOnClickListener(v->{boolean opening=inner.getVisibility()!=View.VISIBLE;
            inner.setVisibility(opening?View.VISIBLE:View.GONE);
            toggle.setText((opening?"▾  ":"▸  ")+label);
        });
        return inner;
    }
    private ArrayList<String> extractImages(Element source){
        LinkedHashSet<String> links=new LinkedHashSet<>();
        for(Element img:source.select("img[src],img[data-src],img[data-original]")){
            String u=img.hasAttr("data-src")?img.absUrl("data-src"):img.hasAttr("data-original")?img.absUrl("data-original"):img.absUrl("src");
            if(usefulImage(u,img))links.add(u);
        }
        // Rutor descriptions may contain escaped image markup inside text nodes.
        String html=org.jsoup.parser.Parser.unescapeEntities(source.html(),false).replace("&quot;","\"");
        java.util.regex.Matcher m=java.util.regex.Pattern.compile("(?i)(?:src|data-src)\\s*=\\s*['\"](https?://[^'\"\\s<>]+\\.(?:jpg|jpeg|png|webp))").matcher(html);
        while(m.find())links.add(m.group(1));
        ArrayList<String> result=new ArrayList<>();
        for(String u:links){if(result.size()>=8)break;result.add(u);}
        return result;
    }
    private boolean usefulImage(String url,Element img){
        if(!url.startsWith("http"))return false;
        String lower=url.toLowerCase(Locale.ROOT);
        if(lower.contains("magnet")||lower.contains("logo")||lower.contains("button")||lower.contains("icon")||lower.contains("rating")||lower.contains("counter")||lower.contains("favicon")||lower.endsWith(".gif"))return false;
        String w=img.attr("width"),h=img.attr("height");
        try{if(!w.isEmpty()&&Integer.parseInt(w.replaceAll("[^0-9]",""))<75)return false;
            if(!h.isEmpty()&&Integer.parseInt(h.replaceAll("[^0-9]",""))<75)return false;}catch(Exception ignored){}
        return true;
    }
    private void addRemoteImage(LinearLayout target,String url,int maxHeight){
        ImageView view=new ImageView(this);view.setAdjustViewBounds(true);
        view.setScaleType(ImageView.ScaleType.FIT_CENTER);view.setMaxHeight(dp(maxHeight));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(dp(6),dp(8),dp(6),dp(8));target.addView(view,lp);
        pool.execute(()->{try{
            java.net.HttpURLConnection conn=(java.net.HttpURLConnection)new java.net.URL(url).openConnection();
            conn.setConnectTimeout(9000);conn.setReadTimeout(9000);conn.setRequestProperty("User-Agent","Mozilla/5.0");
            android.graphics.BitmapFactory.Options opt=new android.graphics.BitmapFactory.Options();opt.inSampleSize=2;
            android.graphics.Bitmap bitmap=android.graphics.BitmapFactory.decodeStream(conn.getInputStream(),null,opt);
            conn.disconnect();if(bitmap!=null)runOnUiThread(()->{if(view.getParent()!=null)view.setImageBitmap(bitmap);});
        }catch(Exception ignored){}});
    }
    private void showDetail(String url,String title,boolean addHistory){
        screen="detail";currentUrl=url;currentTitle=title;init("");
        // Detail screen has no visible toolbar: Android system Back remains active.
        root.removeView(bar);
        TextView heading=text(org.jsoup.parser.Parser.unescapeEntities(title,false),13,true);
        heading.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        heading.getPaint().setFakeBoldText(true);
        heading.setTextColor(Color.BLACK);
        heading.setBackgroundColor(YELLOW);
        heading.setPadding(dp(10),dp(5),dp(10),dp(5));
        heading.setIncludeFontPadding(false);
        body.addView(heading,new LinearLayout.LayoutParams(-1,-2));
        TextView star=text("☆ Добавить в избранное",15,true);body.addView(star);
        star.setOnClickListener(v->{Set<String> values=new HashSet<>(prefs.getStringSet("favorites",Collections.emptySet()));
            String item=title+"|"+url;if(values.contains(item)){values.remove(item);star.setText("☆ Добавить в избранное");}
            else{values.add(item);star.setText("★ В избранном");}
            prefs.edit().putStringSet("favorites",values).apply();});
        LinearLayout content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);body.addView(content);
        content.addView(text("Загрузка раздачи…",15,false));
        pool.execute(()->{try{
            Document doc=Jsoup.connect(url).userAgent("Mozilla/5.0 (Android; Mobile) Chrome/120.0").timeout(18000).get();
            Element desc=doc.selectFirst("#details, .torrent-description, #content, #index");if(desc==null)desc=doc.body();
            Element contentSource=desc;
            Element torrentBlock=doc.selectFirst("#details");if(torrentBlock!=null)contentSource=torrentBlock;
            String description=cleanDescription(contentSource);
            ArrayList<String> imgs=new ArrayList<>();
            imgs.addAll(extractImages(contentSource));
            String torrent=null,magnet=null;
            for(Element a:doc.select("a[href]")){
                String href=a.absUrl("href");String label=a.text().toLowerCase(Locale.ROOT);
                if(magnet==null&&href.startsWith("magnet:"))magnet=href;
                if(torrent==null&&(href.matches("(?i).*\\.torrent(\\?.*)?$")||href.contains("/download/")||label.contains("скачать торрент")))torrent=href;
            }
            Element comments=doc.selectFirst("#comments, .comments, #comment, #comments-list");
            String commentText=comments==null?"Комментарии не удалось извлечь из страницы":cleanDescription(comments);
            String tor=torrent,mag=magnet;
            runOnUiThread(()->{
                if(!screen.equals("detail")||!currentUrl.equals(url))return;
                content.removeAllViews();
                if(!imgs.isEmpty()){
                    addSection(content,"Постер");
                    addRemoteImage(content,imgs.get(0),420);
                }else content.addView(text("Постер не найден на странице раздачи",13,false));
                addSection(content,"Описание раздачи");
                LinearLayout descriptionPanel=new LinearLayout(this);
                descriptionPanel.setOrientation(LinearLayout.VERTICAL);
                descriptionPanel.setBackground(shape());
                content.addView(descriptionPanel,new LinearLayout.LayoutParams(-1,-2));
                String[] parts=splitDescription(description);
                descriptionPanel.addView(compactText(parts[0].isEmpty()?"Описание отсутствует":parts[0]));
                if(!parts[1].isEmpty()){
                    LinearLayout technical=spoiler(content,"Техническая информация");
                    technical.addView(compactText(parts[1]));
                }
                if(imgs.size()>1){
                    LinearLayout gallery=spoiler(content,"Скриншоты и другие изображения ("+(imgs.size()-1)+")");
                    for(int i=1;i<imgs.size();i++)addRemoteImage(gallery,imgs.get(i),340);
                }
                addSplitDownloadAction(content,tor,mag);
                addSection(content,"Комментарии");
                content.addView(text(commentText,14,false));
            });
        }catch(Exception e){runOnUiThread(()->{if(screen.equals("detail")&&currentUrl.equals(url)){
            content.removeAllViews();content.addView(text("Ошибка загрузки: "+e.getMessage(),15,false));}});}});
    }
    private void openLink(String url){try{Intent i=new Intent(Intent.ACTION_VIEW,android.net.Uri.parse(url));startActivity(i);}catch(Exception e){Toast.makeText(this,"Нет приложения для открытия ссылки",Toast.LENGTH_LONG).show();}}
    private void goBack(){if(screen.equals("detail")){if(!history.isEmpty()){String[] prev=history.pop().split("\\|",2);showDetail(prev[0],prev.length>1?prev[1]:"Раздача",false);}else showList(listUrl,favoritesMode);}else if(screen.equals("search"))showList(listUrl,favoritesMode);else super.onBackPressed();}
    @Override public void onBackPressed(){goBack();}
    @Override protected void onDestroy(){pool.shutdownNow();super.onDestroy();}
}
