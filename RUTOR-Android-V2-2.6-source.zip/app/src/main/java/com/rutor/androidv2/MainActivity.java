package com.rutor.androidv2;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.*;
import android.text.method.LinkMovementMethod;
import android.view.*;
import android.widget.*;
import org.jsoup.*;
import org.jsoup.nodes.*;
import org.jsoup.select.Elements;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    private static final String BASE = "https://rutor.info";
    private final ExecutorService pool = Executors.newFixedThreadPool(4);
    private final int BG = Color.BLACK, FG = Color.WHITE, ACCENT = Color.rgb(88,200,239);
    private final int YELLOW = Color.rgb(255,220,0), RED = Color.rgb(170,0,0);
    private LinearLayout tableRows;
    private int selectedRow = -1;
    private LinearLayout root, body, bar;
    private String currentUrl = BASE, listUrl = BASE, currentTitle = "", screen = "list";
    private boolean favoritesMode = false;
    private String currentCategory = "0", currentQuery = "";
    private final ArrayDeque<String> history = new ArrayDeque<>();
    private android.content.SharedPreferences prefs;

    @Override public void onCreate(Bundle b) { super.onCreate(b); prefs=getSharedPreferences("rutor",MODE_PRIVATE); showList(BASE,false); }
    private int dp(int n){return (int)(getResources().getDisplayMetrics().density*n+.5f);}
    private TextView text(String s,int size,boolean bold){ TextView t=new TextView(this); t.setText(s);t.setTextColor(FG);t.setTextSize(size); if(bold)t.setTypeface(null,Typeface.BOLD);t.setPadding(dp(12),dp(9),dp(12),dp(9)); return t; }
    private GradientDrawable shape(){GradientDrawable d=new GradientDrawable();d.setColor(Color.rgb(15,15,15));d.setCornerRadius(dp(9));return d;}
    private void init(String title){
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(BG);setContentView(root);
        bar=new LinearLayout(this);bar.setOrientation(LinearLayout.HORIZONTAL);bar.setGravity(Gravity.CENTER_VERTICAL);root.addView(bar);
        if(!screen.equals("list")){TextView back=text("‹",30,true);bar.addView(back);back.setOnClickListener(v->goBack());}
        TextView heading=text(title,20,true);heading.setSingleLine(true);heading.setEllipsize(TextUtils.TruncateAt.END);bar.addView(heading,new LinearLayout.LayoutParams(0,dp(58),1));
        ScrollView sc=new ScrollView(this);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setPadding(dp(8),dp(4),dp(8),dp(20));sc.addView(body);
    }
    private void notice(String message){body.addView(text(message,15,false));}
    private void load(String url, java.util.function.Consumer<Document> done){
        notice("Загрузка…");pool.execute(()->{
            try {Document doc=Jsoup.connect(url).userAgent("Mozilla/5.0 (Android 14; Mobile) AppleWebKit/537.36 Chrome/120.0 Safari/537.36").timeout(18000).followRedirects(true).get();runOnUiThread(()->{if(!isFinishing()){body.removeAllViews();done.accept(doc);}});}
            catch(Exception e){runOnUiThread(()->{if(!isFinishing()){body.removeAllViews();notice("Не удалось загрузить страницу: "+e.getMessage()+"\nПроверь интернет или доступность rutor.info.");}});}
        });
    }
    private TextView cell(String value,int size,boolean bold,int color){
        TextView t=text(value,size,bold);
        t.setTextColor(color);
        t.setPadding(dp(4),dp(9),dp(4),dp(9));
        t.setGravity(Gravity.CENTER_VERTICAL);
        t.setMaxLines(2);
        t.setEllipsize(TextUtils.TruncateAt.END);
        return t;
    }
    private void tableHeader(){
        LinearLayout row=new LinearLayout(this);
        row.setBackgroundColor(YELLOW);
        body.addView(row,new LinearLayout.LayoutParams(-1,dp(43)));
        String[] labels={"Добавлен","Название","Размер","Пиры"};
        int[] weights={13,62,14,11};
        for(int i=0;i<4;i++){
            TextView t=cell(labels[i],12,true,Color.BLACK);
            t.setGravity(Gravity.CENTER);
            row.addView(t,new LinearLayout.LayoutParams(0,-1,weights[i]));
        }
        tableRows=new LinearLayout(this);
        tableRows.setOrientation(LinearLayout.VERTICAL);
        body.addView(tableRows);
    }
    private void tab(LinearLayout parent,String label,boolean active,Runnable action){
        TextView t=cell(label,14,true,active?Color.BLACK:Color.WHITE);
        t.setGravity(Gravity.CENTER);
        GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
          active?new int[]{Color.YELLOW,YELLOW}:new int[]{Color.RED,Color.rgb(90,0,0)});
        d.setCornerRadii(new float[]{dp(7),dp(7),dp(7),dp(7),0,0,0,0});
        t.setBackground(d);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(45),1);
        lp.setMargins(dp(1),0,dp(1),0);
        parent.addView(t,lp);
        t.setOnClickListener(v->action.run());
    }
    private void showList(String url,boolean favorite){
        screen="list";favoritesMode=favorite;listUrl=url;currentUrl=url;selectedRow=-1;
        init("RUTOR V2 • 2.5");
        // Compact navigation: only the category selector remains above the results.
        LinearLayout nav=new LinearLayout(this);body.addView(nav);
        tab(nav,"Категории ▾",true,()->categoryDialog());
        TextView category=text(favorite?"Избранное":(!currentQuery.isEmpty()?"Поиск: "+currentQuery:(!currentCategory.equals("0")?"Категория: "+categoryName(currentCategory):"Раздачи RUTOR")),21,true);
        body.addView(category);
        category.setOnClickListener(v->{currentCategory="0";currentQuery="";showList(BASE,false);});
        LinearLayout searchBar=new LinearLayout(this);
        searchBar.setGravity(Gravity.CENTER_VERTICAL);
        body.addView(searchBar);
        EditText search=new EditText(this);search.setSingleLine(true);
        search.setTextColor(FG);search.setHintTextColor(Color.LTGRAY);
        search.setTextSize(15);search.setHint("Поиск раздач");
        searchBar.addView(search,new LinearLayout.LayoutParams(0,dp(48),1));
        TextView go=cell("Найти",15,true,Color.WHITE);
        go.setBackgroundColor(RED);searchBar.addView(go);
        go.setOnClickListener(v->{String q=search.getText().toString().trim();
          if(!q.isEmpty())performSearch(q);});
        search.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH);
        search.setOnEditorActionListener((v,action,event)->{
            String q=search.getText().toString().trim();
            if(!q.isEmpty())performSearch(q);
            return true;
        });
        tableHeader();
        if(favorite){
            Set<String> saved=prefs.getStringSet("favorites",Collections.emptySet());
            if(saved.isEmpty())tableRows.addView(text("Избранное пока пусто",15,false));
            for(String item:saved){int k=item.indexOf('|');
                if(k>0)addItem(item.substring(0,k),item.substring(k+1),"—","—","—");}
            return;
        }
        tableRows.addView(text("Загрузка раздач…",15,false));
        pool.execute(()->{
            try{
                Document doc=Jsoup.connect(url).userAgent("Mozilla/5.0 (Android; Mobile) Chrome/120.0").timeout(18000).get();
                ArrayList<String[]> found=new ArrayList<>();HashSet<String> seen=new HashSet<>();
                for(Element a:doc.select("tr.gai a[href], tr.tum a[href], #index a[href], table a[href]")){
                    String href=a.absUrl("href"),title=a.text().trim();
                    if(href.matches("(?i).*/torrent/\\d+.*")&&title.length()>3&&seen.add(href)){
                        Element tr=a.closest("tr");
                        String date="—",size="—",peers="—";
                        if(tr!=null){
                            Elements td=tr.select("> td");
                            if(td.size()>0)date=td.get(0).text();
                            if(td.size()>2)size=td.get(td.size()-2).text();
                            if(td.size()>3)peers=td.get(td.size()-1).text();
                        }
                        // Hide the three permanent tracker announcements on the home screen.
                        if(url.equals(BASE) && (title.toLowerCase(Locale.ROOT).contains("новый адрес: rutor")
                            || title.toLowerCase(Locale.ROOT).contains("вечная блокировка в россии")
                            || title.toLowerCase(Locale.ROOT).contains("путеводитель по rutor")))continue;
                        found.add(new String[]{title,href,date,size,peers});
                    }
                }
                runOnUiThread(()->{
                    if(!screen.equals("list")||favoritesMode||!listUrl.equals(url))return;
                    tableRows.removeAllViews();
                    if(found.isEmpty())tableRows.addView(text("Раздачи не найдены. Проверь поисковый запрос или выбери другую категорию.",15,false));
                    for(String[] pair:found)addItem(pair[0],pair[1],pair[2],pair[3],pair[4]);
                });
            }catch(Exception e){runOnUiThread(()->{
                if(screen.equals("list")&&listUrl.equals(url)){
                    tableRows.removeAllViews();
                    tableRows.addView(text("Ошибка загрузки: "+e.getMessage(),15,false));
                }
            });}
        });
    }
    private void searchDialog(){
        EditText field=new EditText(this);
        field.setSingleLine(true);
        new AlertDialog.Builder(this).setTitle("Поиск RUTOR").setView(field)
          .setPositiveButton("Найти",(d,w)->{
              String q=field.getText().toString().trim();
              if(!q.isEmpty())performSearch(q);
          }).setNegativeButton("Отмена",null).show();
    }
    private void addItem(String title,String url,String date,String size,String peers){
        LinearLayout row=new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setBackgroundColor(tableRows.getChildCount()%2==0?Color.rgb(12,12,12):Color.rgb(27,31,33));
        int[] weights={13,62,14,11};
        String[] values={date,"🎬 "+title,size,peers};
        for(int i=0;i<4;i++){
            TextView t=cell(values[i],i==1?15:12,i==1,Color.WHITE);
            if(i!=1)t.setGravity(Gravity.CENTER);
            row.addView(t,new LinearLayout.LayoutParams(0,dp(64),weights[i]));
        }
        View line=new View(this);line.setBackgroundColor(Color.DKGRAY);
        tableRows.addView(row);
        tableRows.addView(line,new LinearLayout.LayoutParams(-1,dp(1)));
        row.setOnClickListener(v->{row.setBackgroundColor(RED);showDetail(url,title,true);});
    }
    private void categoryDialog(){
        String[] labels={"Все категории","Зарубежные фильмы","Наши фильмы","Сериалы","Мультфильмы","Музыка","Игры","Программы","Книги"};
        String[] ids={"0","1","5","4","7","2","8","9","11"};
        new AlertDialog.Builder(this).setTitle("Категории RUTOR")
          .setItems(labels,(dialog,index)->{currentCategory=ids[index];currentQuery="";showList(BASE+"/browse/0/"+ids[index]+"/0/0",false);})
          .setNegativeButton("Отмена",null).show();
    }
    private String categoryName(String id){
        String[] names={"Все категории","Зарубежные фильмы","Наши фильмы","Сериалы","Мультфильмы","Музыка","Игры","Программы","Книги"};
        String[] ids={"0","1","5","4","7","2","8","9","11"};
        for(int i=0;i<ids.length;i++)if(ids[i].equals(id))return names[i];
        return "Раздачи";
    }
    private void performSearch(String query){
        currentQuery=query;
        showList(BASE+"/search/0/"+currentCategory+"/100/2/"+android.net.Uri.encode(query),false);
    }
    private void addSection(LinearLayout target,String title){
        TextView t=text(title,18,true);t.setTextColor(YELLOW);
        t.setPadding(dp(8),dp(15),dp(8),dp(7));target.addView(t);
        View line=new View(this);line.setBackgroundColor(RED);target.addView(line,new LinearLayout.LayoutParams(-1,dp(2)));
    }
    private void addAction(LinearLayout target,String label,String url,int color){
        if(url==null||url.isEmpty())return;
        TextView t=text(label,16,true);t.setGravity(Gravity.CENTER);t.setBackgroundColor(color);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(50));lp.setMargins(0,dp(5),0,dp(5));target.addView(t,lp);
        t.setOnClickListener(v->openLink(url));
    }
    private String cleanDescription(Element source){
        if(source==null)return "Описание отсутствует";
        Element copy=source.clone();
        copy.select("script,style,iframe,form,nav,footer,header,svg,button,input").remove();
        // Screenshot anchors and thumbnails are presented separately, not as raw markup.
        for(Element a:copy.select("a[href]")){
            String h=a.attr("href").toLowerCase(Locale.ROOT);
            if(h.contains("fastpic")||h.matches(".*\\.(jpg|jpeg|png|webp)(\\?.*)?$"))a.remove();
        }
        copy.select("img,table").remove();
        for(Element e:copy.select("br,p,div,li,h1,h2,h3"))e.prependText("\n");
        String t=org.jsoup.parser.Parser.unescapeEntities(copy.wholeText(),false)
          .replace('\u00a0',' ').replaceAll("[ \t]+"," ").replaceAll("\n[ \t]+","\n")
          .replaceAll("\n[ \t]*\n+","\n").trim();
        t=t.replaceAll("(?i)https?://[^\\s<>]+(?:jpg|jpeg|png|webp)(?:\\.html)?","")
           .replaceAll("(?i)<[^>]{1,300}>","")
           .replaceAll("(?m)^[ \t]*(?:Скрины|Скриншоты)[ \t]*$","").trim();
        if(t.length()>6500)t=t.substring(0,6500)+"…";
        return t.isEmpty()?"Описание отсутствует":t;
    }
    // Split release description into reader-facing details and collapsible technical metadata.
    private String[] splitDescription(String description){
        StringBuilder primary=new StringBuilder(), technical=new StringBuilder();
        boolean inTechnical=false;
        for(String raw:description.split("\\n")){
            String line=raw.trim();
            if(line.isEmpty())continue;
            String lower=line.toLowerCase(Locale.ROOT);
            boolean technicalLabel=lower.matches("^(?:файл|формат|качество|видео|аудио|звук|перевод(?:\\s*\\d+)?|субтитры|кодек|размер|битрейт|частота|разрешение|контейнер|релиз|дорожка|скриншоты|mediainfo|general|video|audio|text|complete name|writing application|duration|overall bit rate|frame rate|width|height|language|format profile|codec id|битность|каналы|раздача|источник)\\s*[:：].*")
                ||lower.matches("^(?:файл|mediainfo|видео|аудио|субтитры|технические данные|скриншоты)$");
            boolean narrativeLabel=lower.matches("^(?:название|оригинальное название|год выпуска|год|жанр|режисс[её]р|в ролях|акт[её]ры|описание|сюжет|страна|продолжительность)\\s*[:：].*")
                ||lower.matches("^(?:описание|сюжет|информация о фильме)$");
            if(technicalLabel)inTechnical=true;
            else if(narrativeLabel)inTechnical=false;
            StringBuilder out=inTechnical?technical:primary;
            if(out.length()>0)out.append('\n');
            out.append(line);
        }
        return new String[]{primary.toString(),technical.toString()};
    }
    private TextView compactText(String value){
        TextView t=text(value,14,false);
        t.setPadding(dp(9),dp(5),dp(9),dp(5));
        t.setIncludeFontPadding(false);
        t.setLineSpacing(0f,1.0f);
        return t;
    }
    private LinearLayout spoiler(LinearLayout target,String label){
        LinearLayout wrap=new LinearLayout(this);wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setBackground(shape());
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(5),0,dp(5));target.addView(wrap,lp);
        TextView toggle=text("▸  "+label,15,true);toggle.setTextColor(YELLOW);
        toggle.setPadding(dp(10),dp(11),dp(10),dp(11));wrap.addView(toggle);
        LinearLayout inner=new LinearLayout(this);inner.setOrientation(LinearLayout.VERTICAL);
        inner.setVisibility(View.GONE);wrap.addView(inner);
        toggle.setOnClickListener(v->{boolean opening=inner.getVisibility()!=View.VISIBLE;
            inner.setVisibility(opening?View.VISIBLE:View.GONE);
            toggle.setText((opening?"▾  ":"▸  ")+label);
        });
        return inner;
    }
    private ArrayList<String> extractImages(Element source){
        LinkedHashSet<String> links=new LinkedHashSet<>();
        for(Element img:source.select("img[src],img[data-src],img[data-original]")){
            String u=img.hasAttr("data-src")?img.absUrl("data-src"):img.hasAttr("data-original")?img.absUrl("data-original"):img.absUrl("src");
            if(usefulImage(u,img))links.add(u);
        }
        // Rutor descriptions may contain escaped image markup inside text nodes.
        String html=org.jsoup.parser.Parser.unescapeEntities(source.html(),false).replace("&quot;","\"");
        java.util.regex.Matcher m=java.util.regex.Pattern.compile("(?i)(?:src|data-src)\\s*=\\s*['\"](https?://[^'\"\\s<>]+\\.(?:jpg|jpeg|png|webp))").matcher(html);
        while(m.find())links.add(m.group(1));
        ArrayList<String> result=new ArrayList<>();
        for(String u:links){if(result.size()>=8)break;result.add(u);}
        return result;
    }
    private boolean usefulImage(String url,Element img){
        if(!url.startsWith("http"))return false;
        String lower=url.toLowerCase(Locale.ROOT);
        if(lower.contains("magnet")||lower.contains("logo")||lower.contains("button")||lower.contains("icon")||lower.contains("rating")||lower.contains("counter")||lower.contains("favicon")||lower.endsWith(".gif"))return false;
        String w=img.attr("width"),h=img.attr("height");
        try{if(!w.isEmpty()&&Integer.parseInt(w.replaceAll("[^0-9]",""))<75)return false;
            if(!h.isEmpty()&&Integer.parseInt(h.replaceAll("[^0-9]",""))<75)return false;}catch(Exception ignored){}
        return true;
    }
    private void addRemoteImage(LinearLayout target,String url,int maxHeight){
        ImageView view=new ImageView(this);view.setAdjustViewBounds(true);
        view.setScaleType(ImageView.ScaleType.FIT_CENTER);view.setMaxHeight(dp(maxHeight));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(dp(6),dp(8),dp(6),dp(8));target.addView(view,lp);
        pool.execute(()->{try{
            java.net.HttpURLConnection conn=(java.net.HttpURLConnection)new java.net.URL(url).openConnection();
            conn.setConnectTimeout(9000);conn.setReadTimeout(9000);conn.setRequestProperty("User-Agent","Mozilla/5.0");
            android.graphics.BitmapFactory.Options opt=new android.graphics.BitmapFactory.Options();opt.inSampleSize=2;
            android.graphics.Bitmap bitmap=android.graphics.BitmapFactory.decodeStream(conn.getInputStream(),null,opt);
            conn.disconnect();if(bitmap!=null)runOnUiThread(()->{if(view.getParent()!=null)view.setImageBitmap(bitmap);});
        }catch(Exception ignored){}});
    }
    private void showDetail(String url,String title,boolean addHistory){
        screen="detail";currentUrl=url;currentTitle=title;init("Раздача");
        TextView heading=text(org.jsoup.parser.Parser.unescapeEntities(title,false),19,true);body.addView(heading);
        TextView star=text("☆ Добавить в избранное",15,true);body.addView(star);
        star.setOnClickListener(v->{Set<String> values=new HashSet<>(prefs.getStringSet("favorites",Collections.emptySet()));
            String item=title+"|"+url;if(values.contains(item)){values.remove(item);star.setText("☆ Добавить в избранное");}
            else{values.add(item);star.setText("★ В избранном");}
            prefs.edit().putStringSet("favorites",values).apply();});
        LinearLayout content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);body.addView(content);
        content.addView(text("Загрузка раздачи…",15,false));
        pool.execute(()->{try{
            Document doc=Jsoup.connect(url).userAgent("Mozilla/5.0 (Android; Mobile) Chrome/120.0").timeout(18000).get();
            Element desc=doc.selectFirst("#details, .torrent-description, #content, #index");if(desc==null)desc=doc.body();
            Element contentSource=desc;
            Element torrentBlock=doc.selectFirst("#details");if(torrentBlock!=null)contentSource=torrentBlock;
            String description=cleanDescription(contentSource);
            ArrayList<String> imgs=new ArrayList<>();
            imgs.addAll(extractImages(contentSource));
            String torrent=null,magnet=null;
            for(Element a:doc.select("a[href]")){
                String href=a.absUrl("href");String label=a.text().toLowerCase(Locale.ROOT);
                if(magnet==null&&href.startsWith("magnet:"))magnet=href;
                if(torrent==null&&(href.matches("(?i).*\\.torrent(\\?.*)?$")||href.contains("/download/")||label.contains("скачать торрент")))torrent=href;
            }
            Element comments=doc.selectFirst("#comments, .comments, #comment, #comments-list");
            String commentText=comments==null?"Комментарии не удалось извлечь из страницы":cleanDescription(comments);
            String tor=torrent,mag=magnet;
            runOnUiThread(()->{
                if(!screen.equals("detail")||!currentUrl.equals(url))return;
                content.removeAllViews();
                addAction(content,"⬇ Скачать .torrent",tor,RED);
                addAction(content,"🧲 Открыть Magnet",mag,Color.rgb(0,115,30));
                if(!imgs.isEmpty()){
                    addSection(content,"Постер");
                    addRemoteImage(content,imgs.get(0),420);
                }else content.addView(text("Постер не найден на странице раздачи",13,false));
                addSection(content,"Описание раздачи");
                LinearLayout descriptionPanel=new LinearLayout(this);
                descriptionPanel.setOrientation(LinearLayout.VERTICAL);
                descriptionPanel.setBackground(shape());
                content.addView(descriptionPanel,new LinearLayout.LayoutParams(-1,-2));
                String[] parts=splitDescription(description);
                descriptionPanel.addView(compactText(parts[0].isEmpty()?"Описание отсутствует":parts[0]));
                if(!parts[1].isEmpty()){
                    LinearLayout technical=spoiler(content,"Техническая информация");
                    technical.addView(compactText(parts[1]));
                }
                if(imgs.size()>1){
                    LinearLayout gallery=spoiler(content,"Скриншоты и другие изображения ("+(imgs.size()-1)+")");
                    for(int i=1;i<imgs.size();i++)addRemoteImage(gallery,imgs.get(i),340);
                }
                addSection(content,"Комментарии");
                content.addView(text(commentText,14,false));
            });
        }catch(Exception e){runOnUiThread(()->{if(screen.equals("detail")&&currentUrl.equals(url)){
            content.removeAllViews();content.addView(text("Ошибка загрузки: "+e.getMessage(),15,false));}});}});
    }
    private void openLink(String url){try{Intent i=new Intent(Intent.ACTION_VIEW,android.net.Uri.parse(url));startActivity(i);}catch(Exception e){Toast.makeText(this,"Нет приложения для открытия ссылки",Toast.LENGTH_LONG).show();}}
    private void goBack(){if(screen.equals("detail")){if(!history.isEmpty()){String[] prev=history.pop().split("\\|",2);showDetail(prev[0],prev.length>1?prev[1]:"Раздача",false);}else showList(listUrl,favoritesMode);}else super.onBackPressed();}
    @Override public void onBackPressed(){goBack();}
    @Override protected void onDestroy(){pool.shutdownNow();super.onDestroy();}
}
