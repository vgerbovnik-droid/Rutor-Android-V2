# RUTOR Android V2

Clean Android Java application, dark theme, native listing and detail pages, back navigation, search, favorites, torrent and magnet actions.

## Build

GitHub Actions: Actions > Build RUTOR V2 APK > Run workflow. Download the `RUTOR-V2-debug-APK` artifact after success.

The app retrieves public pages from `rutor.info` using Jsoup. Site HTML, network restrictions and availability can affect scraping. This is an initial test build; it has not been tested on a device.
