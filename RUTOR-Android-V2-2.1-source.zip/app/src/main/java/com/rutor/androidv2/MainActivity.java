package com.rutor.androidv2;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.*;
import android.text.method.LinkMovementMethod;
import android.view.*;
import android.widget.*;
import org.jsoup.*;
import org.jsoup.nodes.*;
import org.jsoup.select.Elements;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    private static final String BASE = "https://rutor.info";
    private final ExecutorService pool = Executors.newSingleThreadExecutor();
    private final int BG = Color.BLACK, FG = Color.WHITE, ACCENT = Color.rgb(88,200,239);
    private final int YELLOW = Color.rgb(255,220,0), RED = Color.rgb(170,0,0);
    private LinearLayout tableRows;
    private int selectedRow = -1;
    private LinearLayout root, body, bar;
    private String currentUrl = BASE, listUrl = BASE, currentTitle = "", screen = "list";
    private boolean favoritesMode = false;
    private final ArrayDeque<String> history = new ArrayDeque<>();
    private android.content.SharedPreferences prefs;

    @Override public void onCreate(Bundle b) { super.onCreate(b); prefs=getSharedPreferences("rutor",MODE_PRIVATE); showList(BASE,false); }
    private int dp(int n){return (int)(getResources().getDisplayMetrics().density*n+.5f);}
    private TextView text(String s,int size,boolean bold){ TextView t=new TextView(this); t.setText(s);t.setTextColor(FG);t.setTextSize(size); if(bold)t.setTypeface(null,Typeface.BOLD);t.setPadding(dp(12),dp(9),dp(12),dp(9)); return t; }
    private GradientDrawable shape(){GradientDrawable d=new GradientDrawable();d.setColor(Color.rgb(15,15,15));d.setCornerRadius(dp(9));return d;}
    private void init(String title){
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(BG);setContentView(root);
        bar=new LinearLayout(this);bar.setOrientation(LinearLayout.HORIZONTAL);bar.setGravity(Gravity.CENTER_VERTICAL);root.addView(bar);
        if(!screen.equals("list")){TextView back=text("‹",30,true);bar.addView(back);back.setOnClickListener(v->goBack());}
        TextView heading=text(title,20,true);heading.setSingleLine(true);heading.setEllipsize(TextUtils.TruncateAt.END);bar.addView(heading,new LinearLayout.LayoutParams(0,dp(58),1));
        ScrollView sc=new ScrollView(this);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setPadding(dp(8),dp(4),dp(8),dp(20));sc.addView(body);
    }
    private void notice(String message){body.addView(text(message,15,false));}
    private void load(String url, java.util.function.Consumer<Document> done){
        notice("Загрузка…");pool.execute(()->{
            try {Document doc=Jsoup.connect(url).userAgent("Mozilla/5.0 (Android 14; Mobile) AppleWebKit/537.36 Chrome/120.0 Safari/537.36").timeout(18000).followRedirects(true).get();runOnUiThread(()->{if(!isFinishing()){body.removeAllViews();done.accept(doc);}});}
            catch(Exception e){runOnUiThread(()->{if(!isFinishing()){body.removeAllViews();notice("Не удалось загрузить страницу: "+e.getMessage()+"\nПроверь интернет или доступность rutor.info.");}});}
        });
    }
    private TextView cell(String value,int size,boolean bold,int color){
        TextView t=text(value,size,bold);
        t.setTextColor(color);
        t.setPadding(dp(4),dp(9),dp(4),dp(9));
        t.setGravity(Gravity.CENTER_VERTICAL);
        t.setMaxLines(2);
        t.setEllipsize(TextUtils.TruncateAt.END);
        return t;
    }
    private void tableHeader(){
        LinearLayout row=new LinearLayout(this);
        row.setBackgroundColor(YELLOW);
        body.addView(row,new LinearLayout.LayoutParams(-1,dp(43)));
        String[] labels={"Добавлен","Название","Размер","Пиры"};
        int[] weights={13,62,14,11};
        for(int i=0;i<4;i++){
            TextView t=cell(labels[i],12,true,Color.BLACK);
            t.setGravity(Gravity.CENTER);
            row.addView(t,new LinearLayout.LayoutParams(0,-1,weights[i]));
        }
        tableRows=new LinearLayout(this);
        tableRows.setOrientation(LinearLayout.VERTICAL);
        body.addView(tableRows);
    }
    private void tab(LinearLayout parent,String label,boolean active,Runnable action){
        TextView t=cell(label,14,true,active?Color.BLACK:Color.WHITE);
        t.setGravity(Gravity.CENTER);
        GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
          active?new int[]{Color.YELLOW,YELLOW}:new int[]{Color.RED,Color.rgb(90,0,0)});
        d.setCornerRadii(new float[]{dp(7),dp(7),dp(7),dp(7),0,0,0,0});
        t.setBackground(d);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(45),1);
        lp.setMargins(dp(1),0,dp(1),0);
        parent.addView(t,lp);
        t.setOnClickListener(v->action.run());
    }
    private void showList(String url,boolean favorite){
        screen="list";favoritesMode=favorite;listUrl=url;currentUrl=url;selectedRow=-1;
        init("RUTOR V2 • 2.1");
        LinearLayout nav=new LinearLayout(this);body.addView(nav);
        tab(nav,"Главная",!favorite&&url.equals(BASE),()->showList(BASE,false));
        tab(nav,"Топ",false,()->showList(BASE+"/top",false));
        tab(nav,"Категории",false,()->showList(BASE,false));
        tab(nav,"Всё",false,()->showList(BASE,false));
        tab(nav,"Поиск",false,()->{searchDialog();});
        tab(nav,"★",favorite,()->showList(listUrl,true));
        TextView category=text(favorite?"Избранное":"Раздачи RUTOR",23,true);
        body.addView(category);
        LinearLayout searchBar=new LinearLayout(this);
        searchBar.setGravity(Gravity.CENTER_VERTICAL);
        body.addView(searchBar);
        EditText search=new EditText(this);search.setSingleLine(true);
        search.setTextColor(FG);search.setHintTextColor(Color.LTGRAY);
        search.setTextSize(15);search.setHint("Поиск раздач");
        searchBar.addView(search,new LinearLayout.LayoutParams(0,dp(48),1));
        TextView go=cell("Найти",15,true,Color.WHITE);
        go.setBackgroundColor(RED);searchBar.addView(go);
        go.setOnClickListener(v->{String q=search.getText().toString().trim();
          if(!q.isEmpty())showList(BASE+"/search/0/0/000/"+android.net.Uri.encode(q),false);});
        tableHeader();
        if(favorite){
            Set<String> saved=prefs.getStringSet("favorites",Collections.emptySet());
            if(saved.isEmpty())tableRows.addView(text("Избранное пока пусто",15,false));
            for(String item:saved){int k=item.indexOf('|');
                if(k>0)addItem(item.substring(0,k),item.substring(k+1),"—","—","—");}
            return;
        }
        tableRows.addView(text("Загрузка раздач…",15,false));
        pool.execute(()->{
            try{
                Document doc=Jsoup.connect(url).userAgent("Mozilla/5.0 (Android; Mobile) Chrome/120.0").timeout(18000).get();
                ArrayList<String[]> found=new ArrayList<>();HashSet<String> seen=new HashSet<>();
                for(Element a:doc.select("tr.gai a[href], tr.tum a[href], #index a[href], table a[href]")){
                    String href=a.absUrl("href"),title=a.text().trim();
                    if(href.matches("(?i).*/torrent/\\d+.*")&&title.length()>3&&seen.add(href)){
                        Element tr=a.closest("tr");
                        String date="—",size="—",peers="—";
                        if(tr!=null){
                            Elements td=tr.select("> td");
                            if(td.size()>0)date=td.get(0).text();
                            if(td.size()>2)size=td.get(td.size()-2).text();
                            if(td.size()>3)peers=td.get(td.size()-1).text();
                        }
                        found.add(new String[]{title,href,date,size,peers});
                    }
                }
                runOnUiThread(()->{
                    if(!screen.equals("list")||favoritesMode||!listUrl.equals(url))return;
                    tableRows.removeAllViews();
                    if(found.isEmpty())tableRows.addView(text("Раздачи не найдены",15,false));
                    for(String[] pair:found)addItem(pair[0],pair[1],pair[2],pair[3],pair[4]);
                });
            }catch(Exception e){runOnUiThread(()->{
                if(screen.equals("list")&&listUrl.equals(url)){
                    tableRows.removeAllViews();
                    tableRows.addView(text("Ошибка загрузки: "+e.getMessage(),15,false));
                }
            });}
        });
    }
    private void searchDialog(){
        EditText field=new EditText(this);
        field.setSingleLine(true);
        new AlertDialog.Builder(this).setTitle("Поиск RUTOR").setView(field)
          .setPositiveButton("Найти",(d,w)->{
              String q=field.getText().toString().trim();
              if(!q.isEmpty())showList(BASE+"/search/0/0/000/"+android.net.Uri.encode(q),false);
          }).setNegativeButton("Отмена",null).show();
    }
    private void addItem(String title,String url,String date,String size,String peers){
        LinearLayout row=new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setBackgroundColor(tableRows.getChildCount()%2==0?Color.rgb(12,12,12):Color.rgb(27,31,33));
        int[] weights={13,62,14,11};
        String[] values={date,"🎬 "+title,size,peers};
        for(int i=0;i<4;i++){
            TextView t=cell(values[i],i==1?15:12,i==1,Color.WHITE);
            if(i!=1)t.setGravity(Gravity.CENTER);
            row.addView(t,new LinearLayout.LayoutParams(0,dp(64),weights[i]));
        }
        View line=new View(this);line.setBackgroundColor(Color.DKGRAY);
        tableRows.addView(row);
        tableRows.addView(line,new LinearLayout.LayoutParams(-1,dp(1)));
        row.setOnClickListener(v->{row.setBackgroundColor(RED);showDetail(url,title,true);});
    }
    private void showDetail(String url,String title,boolean addHistory){
        if(addHistory&&screen.equals("detail"))history.push(currentUrl+"|"+currentTitle);
        screen="detail";currentUrl=url;currentTitle=title;init("Раздача");
        TextView heading=text(title,19,true);body.addView(heading);
        LinearLayout actions=new LinearLayout(this);body.addView(actions);
        TextView star=text("☆ Избранное",15,true);actions.addView(star);star.setOnClickListener(v->{Set<String> values=new HashSet<>(prefs.getStringSet("favorites",Collections.emptySet()));String item=title+"|"+url;if(values.contains(item)){values.remove(item);Toast.makeText(this,"Удалено из избранного",Toast.LENGTH_SHORT).show();}else{values.add(item);Toast.makeText(this,"Добавлено в избранное",Toast.LENGTH_SHORT).show();}prefs.edit().putStringSet("favorites",values).apply();});
        LinearLayout content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);body.addView(content);
        pool.execute(()->{
            try{
                Document doc=Jsoup.connect(url).userAgent("Mozilla/5.0 (Android; Mobile) Chrome/120.0").timeout(18000).get();
                Element desc=doc.selectFirst("#details, .torrent-description, #content, #index");if(desc==null)desc=doc.body();
                String description=desc.text();if(description.length()>16000)description=description.substring(0,16000);
                ArrayList<String[]> links=new ArrayList<>();for(Element a:doc.select("a[href]")){String href=a.absUrl("href");if(href.startsWith("magnet:")||href.matches("(?i).*\\.torrent(\\?.*)?$")||a.text().toLowerCase(Locale.ROOT).contains("скачать .torrent"))links.add(new String[]{a.text(),href});}
                ArrayList<String> images=new ArrayList<>();for(Element img:desc.select("img[src]")){String src=img.absUrl("src");if(src.startsWith("http")&&!images.contains(src)&&images.size()<12)images.add(src);}
                Element comments=doc.selectFirst("#comments, .comments, #comment");String commentText=comments==null?"Комментарии на странице не найдены":comments.text();
                String finalDescription=description;
                runOnUiThread(()->{if(!screen.equals("detail")||!currentUrl.equals(url))return;content.removeAllViews();
                    TextView heading2=text("Описание",18,true);content.addView(heading2);
                    TextView descriptionView=text(finalDescription,15,false);content.addView(descriptionView);
                    for(String[] link:links){TextView button=text(link[0].isEmpty()?"Скачать торрент / Magnet":link[0],15,true);button.setTextColor(ACCENT);content.addView(button);button.setOnClickListener(v->openLink(link[1]));}
                    content.addView(text("Изображения",18,true));
                    if(images.isEmpty())content.addView(text("Изображения не найдены",14,false));
                    for(String imageUrl:images){ImageView image=new ImageView(this);image.setAdjustViewBounds(true);image.setMaxHeight(dp(550));content.addView(image,new LinearLayout.LayoutParams(-1,-2));pool.execute(()->{try{java.net.HttpURLConnection c=(java.net.HttpURLConnection)new java.net.URL(imageUrl).openConnection();c.setConnectTimeout(10000);c.setReadTimeout(10000);android.graphics.Bitmap bitmap=android.graphics.BitmapFactory.decodeStream(c.getInputStream());runOnUiThread(()->image.setImageBitmap(bitmap));c.disconnect();}catch(Exception ignored){}});}
                    content.addView(text("Комментарии",18,true));content.addView(text(commentText,14,false));
                });
            }catch(Exception e){runOnUiThread(()->{content.removeAllViews();content.addView(text("Ошибка загрузки раздачи: "+e.getMessage(),15,false));});}
        });
    }
    private void openLink(String url){try{Intent i=new Intent(Intent.ACTION_VIEW,android.net.Uri.parse(url));startActivity(i);}catch(Exception e){Toast.makeText(this,"Нет приложения для открытия ссылки",Toast.LENGTH_LONG).show();}}
    private void goBack(){if(screen.equals("detail")){if(!history.isEmpty()){String[] prev=history.pop().split("\\|",2);showDetail(prev[0],prev.length>1?prev[1]:"Раздача",false);}else showList(listUrl,favoritesMode);}else super.onBackPressed();}
    @Override public void onBackPressed(){goBack();}
    @Override protected void onDestroy(){pool.shutdownNow();super.onDestroy();}
}
